package ejercicio14.ejercicio14;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TestDateLapse {
	private DateLapse lapsoDeFechas;
	private DateLapse2 lapsoDeFechas2;
	private LocalDate fechaDesde, fechaHasta, fechaEntre1, fechaEntre2;
	
	@BeforeEach
	public void setUp() {
		this.fechaDesde = LocalDate.of(1999, 7, 26);
		this.fechaHasta = LocalDate.of(2002, 2, 9);
		this.fechaEntre1 = LocalDate.of(2000, 7, 11);
		this.fechaEntre2 = LocalDate.of(2004, 9, 30);
		
		this.lapsoDeFechas=new DateLapse(fechaDesde, fechaHasta);
		this.lapsoDeFechas2=new DateLapse2(fechaDesde, 500);

	}
	
	@Test
	public void testCantidadDias() {
		assertTrue(this.lapsoDeFechas.includesDate(this.fechaEntre1));
		assertFalse(this.lapsoDeFechas.includesDate(this.fechaEntre2));
		
		assertTrue(this.lapsoDeFechas2.includesDate(this.fechaEntre1));
		assertFalse(this.lapsoDeFechas2.includesDate(this.fechaEntre2));
	}
}
