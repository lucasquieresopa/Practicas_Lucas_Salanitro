package ar.edu.unlp.info.oo1.ejercicio2_balanza;
import java.time.LocalDate;
import java.util.*;

public class Ticket {
	private LocalDate fecha;
	/*
	private Integer cantidadDeProductos;
	private Double pesoTotal;
	private Double precioTotal;
	*/
	private ArrayList<Producto> listaDeProductos;
	
	public Ticket(ArrayList<Producto> listaDeProductos) {
		this.fecha = LocalDate.now();
		this.listaDeProductos = listaDeProductos;
		
	}
	public LocalDate getFecha() {
		return fecha;
	}
	public void setFecha(LocalDate fecha) {
		this.fecha = fecha;
	}
	/*
	public Integer getCantidadDeProductos() {
		return cantidadDeProductos;
	}
	public void setCantidadDeProductos(Integer cantidadDeProductos) {
		this.cantidadDeProductos = cantidadDeProductos;
	}
	public Double getPesoTotal() {
		return pesoTotal;
	}
	public void setPesoTotal(Double pesoTotal) {
		this.pesoTotal = pesoTotal;
	}
	public Double getPrecioTotal() {
		return precioTotal;
	}
	public void setPrecioTotal(Double precioTotal) {
		this.precioTotal = precioTotal;
	}
	*/
	public Double impuesto() {
		Double precioTotal = 0.0;
		for(int i=0; i<listaDeProductos.size(); i++) {
			precioTotal = precioTotal + listaDeProductos.get(i).getPrecio();
		}
		Double impuesto = (21 * precioTotal)/100;
		return impuesto;
	}
	public List<Producto> getProducto(){
		return this.listaDeProductos;
	}
	
}
