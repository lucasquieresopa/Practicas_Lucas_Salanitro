package ejercicio6.ejercicio6;
import java.util.ArrayList;

public class Farola {

	private Boolean estado;
	private ArrayList<Farola> listaDeVecinas;
	
	public Farola() {
		this.estado = false;
		this.listaDeVecinas = new ArrayList<Farola>();
	}
	
	public void pairWithNeighbour(Farola farolaVecina) {
		if(!(this.listaDeVecinas.contains(farolaVecina))) {
			this.listaDeVecinas.add(farolaVecina);
			farolaVecina.pairWithNeighbour(this);
		}
	}
	
	public ArrayList<Farola> getNeighbours(){
		return this.listaDeVecinas;
	}
	
	public void turnOn() {
		if(this.estado == false) {
			this.estado = true;
			for(Farola f: this.listaDeVecinas) {
				f.turnOn();
			}
			//this.listaDeVecinas.stream().map(farola -> farola.turnOn());
		}
	}
	
	public void turnOff() {
		if(this.estado == true) {
			this.estado = false;
			for(Farola f: this.listaDeVecinas) {
				f.turnOff();
			}
		}
	}
	
	public boolean isOn() {
		return this.estado;
	}


}
