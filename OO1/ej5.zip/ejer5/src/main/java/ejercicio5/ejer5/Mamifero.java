package ejercicio5.ejer5;
import java.util.Date;

public class Mamifero {
	
	private String identificador;
	private String especie;
	private Date fechaNacimiento;
	private Mamifero padre;
	private Mamifero madre;
	
	public Mamifero() {
		
	}
	public Mamifero(String identificador) {
		this.identificador = identificador;
	}
	
	public String getIdentificador() {
		return identificador;
	}
	public void setIdentificador(String identificador) {
		this.identificador = identificador;
	}
	public String getEspecie() {
		return especie;
	}
	public void setEspecie(String especie) {
		this.especie = especie;
	}
	public Date getFechaNacimiento() {
		return fechaNacimiento;
	}
	public void setFechaNacimiento(Date fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}
	public Mamifero getPadre() {
		return padre;
	}
	public void setPadre(Mamifero padre) {
		this.padre = padre;
	}
	public Mamifero getMadre() {
		return madre;
	}
	public void setMadre(Mamifero madre) {
		this.madre = madre;
	}
	
	public Mamifero getAbueloMaterno() {
		if(this.getMadre() != null) {
			return this.getMadre().getPadre();
		}
		else return null;
		/*
		if(!(this.getMadre().equals(null))) {
			return this.madre.getPadre();
		}
		else return null;
		*/
		//no se puede hacer .equals(null) ???
	}

	public Mamifero getAbuelaMaterna() {
		if(this.getMadre() != null) {
			return this.getMadre().getMadre();
		}
		else return null;
	}

	public Mamifero getAbueloPaterno() {
		if(this.getPadre() != null) {
			return this.getPadre().getPadre();
		}
		else return null;
	}

	public Mamifero getAbuelaPaterna() {
		if(this.getPadre() != null) {
			return this.getPadre().getMadre();
		}
		else return null;
	}

	private Boolean tieneComoAncestroA_(Mamifero ancestro, Mamifero unMamifero) {
		if(ancestro == null) {
			return false;
		}
		return (ancestro == unMamifero) || (ancestro.tieneComoAncestroA(unMamifero));
		
		/*
		if(ancestro == null) {
			return false;
		}
		else {
			if(ancestro == unMamifero) {
				return true;
			}
			else {
				return ancestro.tieneComoAncestroA(unMamifero);
			}
		}
		*/
	}
	
	
	public Boolean tieneComoAncestroA(Mamifero unMamifero) {
		if(this == unMamifero) {
			return false;
		}
		else {
			return tieneComoAncestroA_(this.getMadre(), unMamifero) || tieneComoAncestroA_(this.getPadre(), unMamifero);
		}
	}	
			/*
			 * 
			if(this == unMamifero) {
				return false;
			}
			else{
				Boolean esAncestro = false;
				if(this.getMadre() != null) { 
					if(this.getMadre() != unMamifero) {
						esAncestro = this.getMadre().tieneComoAncestroA(unMamifero);
					}
					else {
						return true;
					}
				}
				Boolean esAncestro2 = false;
				if(this.getPadre() != null) {
					if(this.getPadre() != unMamifero) {
						esAncestro2 = this.getPadre().tieneComoAncestroA(unMamifero);
					}
					else {
						return true;
					}
				}
				return esAncestro || esAncestro2;
			}
		*/
}
