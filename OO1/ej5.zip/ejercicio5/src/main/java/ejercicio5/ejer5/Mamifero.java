package ejercicio5.ejer5;
import java.util.Date;

public class Mamifero {
	
	private String identificador;
	private String especie;
	private Date fechaNacimiento;
	private Mamifero padre;
	private Mamifero madre;
	
	public Mamifero() {
		
	}
	public Mamifero(String identificador) {
		this.identificador = identificador;
	}
	
	public String getIdentificador() {
		return identificador;
	}
	public void setIdentificador(String identificador) {
		this.identificador = identificador;
	}
	public String getEspecie() {
		return especie;
	}
	public void setEspecie(String especie) {
		this.especie = especie;
	}
	public Date getFechaNacimiento() {
		return fechaNacimiento;
	}
	public void setFechaNacimiento(Date fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}
	public Mamifero getPadre() {
		return padre;
	}
	public void setPadre(Mamifero padre) {
		this.padre = padre;
	}
	public Mamifero getMadre() {
		return madre;
	}
	public void setMadre(Mamifero madre) {
		this.madre = madre;
	}
	
	public Mamifero getAbueloMaterno() {
		if(this.getMadre() != null) {
			return this.getMadre().getPadre();
		}
		else return null;
		/*
		if(!(this.getMadre().equals(null))) {
			return this.madre.getPadre();
		}
		else return null;
		*/
		//no se puede hacer .equals(null) ???
	}

	public Mamifero getAbuelaMaterna() {
		if(this.getMadre() != null) {
			return this.getMadre().getMadre();
		}
		else return null;
	}

	public Mamifero getAbueloPaterno() {
		if(this.getPadre() != null) {
			return this.getPadre().getPadre();
		}
		else return null;
	}

	public Mamifero getAbuelaPaterna() {
		if(this.getPadre() != null) {
			return this.getPadre().getMadre();
		}
		else return null;
	}

	
	public Boolean tieneComoAncestroA(Mamifero unMamifero) {
		//está mal porque devuelve true cuando unMamifero es el mismo que el primer Mamifero
		if(this == unMamifero) {
			return true;
		}
		else {
			if(this.getMadre() != null) {
				this.getMadre().tieneComoAncestroA(unMamifero);
			}
			if(this.getPadre() != null) {
				this.getPadre().tieneComoAncestroA(unMamifero);
			}
			return false;
		}
		/*
		else {
			if(!(this.madre.equals(null))) {
				Mamifero nuevaMadre = this.madre;
				nuevaMadre.tieneComoAncestroA(unMamifero);
			}
			if(!(this.padre.equals(null))) {
				Mamifero nuevoPadre = this.padre;
				nuevoPadre.tieneComoAncestroA(unMamifero);
				
			}
		}
		return false;
		*/
	}
	
	
}
