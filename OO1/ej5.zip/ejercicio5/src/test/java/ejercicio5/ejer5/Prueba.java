package ejercicio5.ejer5;

public class Prueba {
	public static void main(String[]args) {
		
		Mamifero mm = new Mamifero();
		System.out.println(mm.getMadre());
		
		//mm.setMadre(new Mamifero("Hola"));
		//System.out.println(mm.getMadre().getIdentificador());
		
		System.out.println(mm.getAbuelaMaterna());
		
		Mamifero madre = new Mamifero("Madre");
		Mamifero abuela = new Mamifero("Abuela");
		mm.setMadre(madre);
		madre.setMadre(abuela);
		System.out.println(mm.getAbuelaMaterna());
	}
}
