package ar.edu.unlp.info.oo1.ejercicio3;
import java.time.LocalDate;
import java.util.*;

public class Presupuesto {

	private LocalDate fecha;
	private String cliente;
	
	private List<Item> listaDeItems;
	
	public Presupuesto(String cliente) {
		this.cliente = cliente;
		this.fecha = LocalDate.now();
		this.listaDeItems = new ArrayList<Item>();
	}
	
	public void setFecha(LocalDate fecha) {
		this.fecha = fecha;
	}
	
	public void setCliente(String cliente) {
		this.cliente = cliente;
	}
	
	public void agregarItem(Item item) {
		this.listaDeItems.add(item);
	}
	
	public Double calcularTotal() {
		Double total = 0.0;
		
		Iterator<Item> iter = listaDeItems.iterator();
		while (iter.hasNext()) {
		    total = total + iter.next().getCostoUnitario();
		}
		return total;
	}
	
	//si quiero acceder con .cliente() tengo que hacer
	//las variables de instancia publicas? y luego de eso?

	//como hacer la lista correctamente
}
