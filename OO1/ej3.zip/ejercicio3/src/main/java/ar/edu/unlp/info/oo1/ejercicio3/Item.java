package ar.edu.unlp.info.oo1.ejercicio3;

public class Item {

	private String detalle;
	private Integer cantidad;
	private Double costoUnitario;
	
	public Item() {
		
	}
	
	public Item(String detalle, Integer cantidad,
			Double costoUnitario) {
		this.detalle = detalle;
		this.cantidad = cantidad;
		this.costoUnitario = costoUnitario;
	}
	
	public Double getCostoUnitario() {
		return this.costoUnitario;
	}
	
	public Double costo() {
		return (this.costoUnitario * this.cantidad);
	}
	
	//como hago para darle valor a detalle con Item().detalle();
}
