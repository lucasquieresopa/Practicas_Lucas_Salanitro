package ejercicio14.ejercicio14;

import java.time.LocalDate;

public class DateLapse2 implements DateLapseInterface{

	private LocalDate from;
	private int sizeInDays;
	
	public DateLapse2(LocalDate desde, int cantidadDeDias) {
		this.from = desde;
		this.sizeInDays = cantidadDeDias;
	}
	
	public LocalDate getFrom() {
		return this.from;
	}
	public LocalDate getTo() {
		return this.from.plusDays(sizeInDays);
	}
	public int sizeInDays() {
		return this.sizeInDays;
	}
	public boolean includesDate(LocalDate other) {
		return other.isAfter(this.from) && other.isBefore(this.getTo());
	}
}
