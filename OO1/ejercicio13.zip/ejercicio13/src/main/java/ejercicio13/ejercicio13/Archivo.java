package ejercicio13.ejercicio13;

public class Archivo {

	private String nombre;
	
	public String getNombre() {
		return this.nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public Double tamaño() {
		return (double) this.nombre.length();
	}
	
	
	
	public Archivo(String nombre) {
		this.nombre=nombre;
	}
}
