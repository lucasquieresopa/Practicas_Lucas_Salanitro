package ejercicio13.ejercicio13;

import java.util.ArrayList;
import java.util.List;

public class ClienteDeCorreo {
	private Carpeta inbox;
	private List<Carpeta> carpetas;
	
	public ClienteDeCorreo() {
		this.carpetas= new ArrayList<Carpeta>();
		this.inbox=new Carpeta("Inbox");
	}
	
	public void recibir(Email email) {
		this.inbox.almacenar(email);
	}
	public void mover(Email email, Carpeta origen, Carpeta destino) {
		//quita el email de la carpeta origen removiendolo de
		//la lista de emails que posee carpeta y lo agrega a la
		//lista de emails de la carpeta destino
		origen.remover(email);
		destino.almacenar(email);
	}
	
	public Email buscar(String texto) {
		if(this.carpetas.isEmpty()) {
			return null;
		}
		else {
			Email e=null;
			while(this.carpetas.iterator().hasNext()) {
				e = this.carpetas.iterator().next().buscar(texto);
			}
			return e;
		}
	}

//Opcion buscar 1
//	public Email buscar(String texto) {
//		//mientras no se encuentre
//		//para c/carpeta de this.carpetas
//		//comparar si el nombre == a texto
//		//devolver cuando sea true
//	
//		if(this.carpetas.isEmpty()) {
//			return null;
//		}
//		//mientras haya otra carpeta en la lista
//		while(this.carpetas.iterator().hasNext()) {
//			//se toma la carpeta actual y se pasa el puntero a la sig
//			Carpeta c = this.carpetas.iterator().next();
//			//tomo la lista de emails de dicha carpeta
//			List<Email> emails = c.getEmails();
//			if(!(emails.isEmpty())) {
//				//mientras haya otro email en la lista
//				while(emails.iterator().hasNext()) {
//					//tomo el email y pongo el puntero en el sig
//					Email e = emails.iterator().next();
//					//chequeo si contiene el texto en su titulo o su cuerpo
//					if(e.getTitulo().contains(texto) || (e.getCuerpo().contains(texto))) {
//						return e;
//					}
//				}
//			}
//		}
//		//si luego de recorrer c/email de c/carpeta 
//		//no se halló, devuelve null
//		return null;
//	}
	
	public Integer espacioOcupado() {
		//para c/carpeta sumar espacios
		
		return this.carpetas.stream()
				.mapToInt(carpeta -> carpeta.espacioOcupado())
				.sum();
	}
	
	
	//metodos implementados para test
	public Carpeta getInbox() {
		return this.inbox;
	}
	public void agregarCarpeta(Carpeta carpeta) {
		this.carpetas.add(carpeta);
	}
}
