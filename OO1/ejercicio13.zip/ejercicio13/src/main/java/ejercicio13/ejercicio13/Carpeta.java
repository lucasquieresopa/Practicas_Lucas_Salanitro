package ejercicio13.ejercicio13;

import java.util.ArrayList;
import java.util.List;

public class Carpeta {
	private String nombre;
	private List<Email> emails;
	
	public String getNombre() {
		return this.nombre;
	}
	public void almacenar(Email email) {
		emails.add(email);
	}
	public void remover(Email email) {
		emails.remove(email);
	}
	public List<Email> getEmails(){
		return this.emails;
	}
	
	public Email buscar(String texto) {
		//busca dentro de la lista this.emails un email
		//cuyo titulo o cuerpo contenga 'texto' y lo devuelve
		//al momento de hallarlo
		if(this.emails.isEmpty()) {
			return null;
		}
		else {
			Email e=null;
			while(emails.iterator().hasNext()) {
				//tomo el email y pongo el puntero en el sig
				e = emails.iterator().next();
				//chequeo si contiene el texto en su titulo o su cuerpo
				if(e.getTitulo().contains(texto) || (e.getCuerpo().contains(texto))) {
					break;
				}
			}
			return e;
		}
		
	}
	
	public Integer espacioOcupado() {
		//Devuelve la suma de los espacios de todos los archivos
		return this.emails.stream()
				.mapToInt(email -> email.espacioOcupado())
				.sum();
	}



	public Carpeta(String nombre) {
		this.nombre=nombre;
		this.emails=new ArrayList<Email>();
	}
}
//en buscar seria mejor instanciar un mail vacio en vez de asignar en null?
//asi si no se haya el valor no devuelve un mail nulo, sino uno vacio
