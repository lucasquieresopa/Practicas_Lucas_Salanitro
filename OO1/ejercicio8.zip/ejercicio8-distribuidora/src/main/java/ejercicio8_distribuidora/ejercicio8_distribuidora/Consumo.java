package ejercicio8_distribuidora.ejercicio8_distribuidora;
import java.time.LocalDate;

public class Consumo {
	private LocalDate fecha;
	private Double consumoEnergiaActiva;
	private Double consumoEnergiaReactiva;
	
	public Consumo(LocalDate fecha, double consumoEnergiaActiva,
			double consumoEnergiaReactiva) {
		this.fecha = fecha;
		this.consumoEnergiaActiva = consumoEnergiaActiva;
		this.consumoEnergiaReactiva = consumoEnergiaReactiva;
	}
	
	public Double costoEnBaseA(Double precioKWh) {
			return this.consumoEnergiaActiva * precioKWh;
	}
	
	public Double factorDePotencia(){
		return this.consumoEnergiaActiva / 
				Math.sqrt(Math.pow(this.consumoEnergiaActiva, 2) +
				Math.pow(this.consumoEnergiaReactiva, 2));
	}
	
	public LocalDate getFecha() {
		return this.fecha;
	}
	
	public Double getConsumoEnergiaActiva() {
		return this.getConsumoEnergiaActiva();
	}
}
