package ejercicio8_distribuidora.ejercicio8_distribuidora;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Usuario {
	private String domicilio;
	private String nombre;
	private List<Consumo> listaConsumo;
	private List<Factura> listaFacturas;
	
	public Usuario() {
		
	}
	public Usuario(String unDomicilio, String unNombre) {
		this.domicilio = unDomicilio;
		this.nombre = unNombre;
		this.listaConsumo = new ArrayList<Consumo>();
		this.listaFacturas = new ArrayList<Factura>();
	}
	public void agregarMedicion(Consumo medicion) {
		this.listaConsumo.add(medicion);
	}
	
	public Double ultimoConsumoActiva() {
		//deberia devolverme el costo de consumo(double) del
		//objeto consumo con fecha mas actual
		if (!this.listaConsumo.isEmpty()){
			Comparator<Consumo> comparadorDeConsumos = 
					Comparator.comparing(c -> c.getFecha());
			return this.listaConsumo.stream().max(comparadorDeConsumos).get()
					.getConsumoEnergiaActiva();
			
		}
		else return 0.0;
	}
	public List<Consumo> getListaConsumo() {
		return listaConsumo;
	}
	public List<Factura> getListaFacturas() {
		return listaFacturas;
	}
	public Consumo ultimoConsumo() {
		//devuelve el consumo con fecha mas actual
		return this.listaConsumo.stream()
		 		.max(Comparator.comparing(c -> c.getFecha()))
		 		.orElse(null);
	}
	
	public Factura facturarEnBaseA(double precioKWh) {
		//posibles casos: devuelve null (lista de consumos vacia)
		//Devuelve > 0 (lista con consumos, hallo uno)
		Consumo ultimoConsumo = this.ultimoConsumo();
		if(ultimoConsumo == null) {
			return new Factura(0.0, 0.0, this);
		}
		else {
			if(ultimoConsumo.factorDePotencia() > 0.8)
				return new Factura(this.ultimoConsumoActiva(), this.ultimoConsumoActiva()/10, this);
			else
				return new Factura(this.ultimoConsumoActiva(), 0.0, this);
		}
	}
	public List<Factura> facturas() {
		return this.listaFacturas; //.clone();
		
		
	}
	public String getDomicilio() {
		return domicilio;
	}
	public void setDomicilio(String domicilio) {
		this.domicilio = domicilio;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public void agregarFactura(Factura f) {
		this.listaFacturas.add(f);
	}
	
}

/*
 * consultas:
 * -si el planteo de ultimoConsumoActiva y ultimoConsumo estan bien
 * -como emplear el .clone()
 * -en uml dice Facturas[*], que significa?
 * -lista de facturas no se usa nunca?
 */
