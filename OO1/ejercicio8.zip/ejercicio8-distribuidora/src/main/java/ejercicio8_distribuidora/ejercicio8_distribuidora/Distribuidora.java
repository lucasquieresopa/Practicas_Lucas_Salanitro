package ejercicio8_distribuidora.ejercicio8_distribuidora;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Distribuidora {
	private Double precioKWh;
	private List<Usuario> listaUsuarios;
	//private List<Factura> listaFacturas;
	
	public Distribuidora(double precio) {
		this.precioKWh = precio;
		this.listaUsuarios = new ArrayList<Usuario>(); 
		//this.listaFacturas = new ArrayList<Factura>();
	}
	
	public void agregarUsuario(Usuario usuario) {
		this.listaUsuarios.add(usuario);
	}
	public List<Factura> facturar(){
		return this.listaUsuarios.stream()
				.map(usu -> usu.facturarEnBaseA(this.precioKWh))
				.collect(Collectors.toList());
			
	}

	public Double consumoTotalActiva() {
		//suma los ultimos consumos de cada usuario
		return listaUsuarios.stream()
				.map(c -> c.facturarEnBaseA(this.precioKWh))
				.mapToDouble(c -> c.montoTotal())
				.sum();
	}
	public void setPrecioKWh(Double precio) {
		this.precioKWh = precio;
	}

	public Double getPrecioKWh() {
		return precioKWh;
	}

	public List<Usuario> getUsuarios() {
		return listaUsuarios;
	}
}
