package ejercicio8_distribuidora.ejercicio8_distribuidora;

import java.time.LocalDate;

public class Factura {
	private Double montoEnergiaActiva;
	private Double descuento;
	private LocalDate fecha;
	private Usuario usuario;
	
	public Factura(double montoEnergiaActiva,
			double descuento, Usuario usuario) {
		this.fecha = LocalDate.now();
		this.montoEnergiaActiva = montoEnergiaActiva;
		this.usuario = usuario;
		this.descuento = descuento;
	}
	
	public Double montoTotal() {
		return this.montoEnergiaActiva - this.descuento;
	}
	public Usuario getUsuario() {
		return this.usuario;
	}
	public LocalDate getFecha() {
		return this.fecha;
	}
	public Double getDescuento() {
		return this.descuento;
	}

	public Double getMontoEnergiaActiva() {
		return this.montoEnergiaActiva;
	}
}
