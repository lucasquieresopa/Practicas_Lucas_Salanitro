package ar.edu.unlp.info.oo1.ej8_distribuidora;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import ejercicio8_distribuidora.ejercicio8_distribuidora.Consumo;
import ejercicio8_distribuidora.ejercicio8_distribuidora.Distribuidora;
import ejercicio8_distribuidora.ejercicio8_distribuidora.Factura;
import ejercicio8_distribuidora.ejercicio8_distribuidora.Usuario;

public class TestDistribuidora {
	private Distribuidora distrib;
	private Usuario edgar, claudio;

	
	@BeforeEach
	void setUp() throws Exception{
		this.distrib = new Distribuidora(10.0);
		this.edgar = new Usuario("44 y 5", "edgar");
		this.claudio = new Usuario("66 y 8", "claudio");
	}
	
	@Test
	public void iniciarSistema() {
		//evaluacion del constructor
		assertEquals(10.0, this.distrib.getPrecioKWh());
		assertTrue(this.distrib.getUsuarios().isEmpty());
	}
	
	@Test
	public void agregarUsuario() {
		//Usuario usuario = new Usuario("44 y 5", "edgar");
		this.distrib.agregarUsuario(this.edgar);
		assertEquals(1, this.distrib.getUsuarios().size());
		assertTrue(this.distrib.getUsuarios().contains(this.edgar));
	}
	
	@Test
	public void agregarConsumoAUsuario() {
		//Usuario usuario = new Usuario("44 y 5", "Claudio");
		assertEquals(0, this.edgar.getListaConsumo().size());
		this.edgar.agregarMedicion(new Consumo(LocalDate.now(), 80.0, 50.0));
		assertFalse(this.edgar.getListaConsumo().isEmpty());
		assertEquals(1, this.edgar.getListaConsumo().size());
	}
	
	@Test
	public void emitirFacturas() {
		this.distrib.agregarUsuario(this.claudio);
		this.edgar.agregarFactura(new Factura(6, 77, edgar));
		this.edgar.agregarFactura(new Factura(55, 77, edgar));
		this.claudio.agregarFactura(new Factura(88, 9, claudio));
		this.claudio.agregarFactura(new Factura(100, 50, claudio));
		
		assertEquals(2, this.distrib.facturar().size());
		
		
	}
	
	
}
