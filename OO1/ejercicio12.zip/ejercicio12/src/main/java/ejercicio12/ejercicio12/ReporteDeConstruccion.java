package ejercicio12.ejercicio12;

import java.util.ArrayList;
import java.util.List;

public class ReporteDeConstruccion {

		private List<Pieza> piezas;
		
		public ReporteDeConstruccion() {
			this.piezas = new ArrayList<Pieza>();
		}
		
		public Double volumenDeMaterial(String material) {
			//recorrer this.piezas, tomando solo los valores 
			//getMaterial.equals(material) y sumandolos
			//con calcularVolumen()
			
			return this.piezas.stream()
					.filter(pieza -> pieza.getMaterial().equals(material))
					.mapToDouble(pieza -> pieza.calcularVolumen())
					.sum();
			
		}
		public Double superficieDeColor(String color) {
			//recorrer this.piezas, tomando solo los valores 
			//getColor.equals(color) y sumandolos su volumenes
			//con calcularVolumen()
			
			return this.piezas.stream()
					.filter(pieza -> pieza.getColor().equals(color))
					.mapToDouble(pieza -> pieza.calcularSuperficie())
					.sum();
		}
		public void agregarPieza(Pieza pieza) {
			this.piezas.add(pieza);
		}
}
