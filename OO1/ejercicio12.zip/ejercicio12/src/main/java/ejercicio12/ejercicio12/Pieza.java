package ejercicio12.ejercicio12;

public abstract class Pieza {
	
	private String material;
	private String color;
	
	public abstract Double calcularVolumen();
	public abstract Double calcularSuperficie();
	
	public String getColor() {
		return this.color;
	}
	public String getMaterial() {
		return this.material;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public void setMaterial(String material) {
		this.material = material;
	}
}
