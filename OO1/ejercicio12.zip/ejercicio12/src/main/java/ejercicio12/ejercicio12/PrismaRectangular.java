package ejercicio12.ejercicio12;

public class PrismaRectangular extends Pieza{

		private Integer ladoMayor;
		private Integer ladoMenor;
		private Integer altura;
		
		public PrismaRectangular(Integer ladoMayor, Integer ladoMenor, Integer altura, String color, String material) {
			this.ladoMayor = ladoMayor;
			this.ladoMenor = ladoMenor;
			this.altura = altura;
			super.setColor(color);
			super.setMaterial(material);
		}
		
		@Override
		public Double calcularVolumen() {

			return (double) (this.ladoMayor * this.ladoMenor * this.altura);
		}
		@Override
		public Double calcularSuperficie() {
			return (double)(2 * (this.ladoMayor * this.ladoMenor + this.ladoMayor * this.altura + this.ladoMenor * this.altura));
		}
		public String getColor() {
			return super.getColor();
		}
		public String getMaterial() {
			return super.getMaterial();
		}
}

//Son todos los valores integer, entonces o los metodos deberian devolver tipo
//de dato Integer, o los valores deberian ser double