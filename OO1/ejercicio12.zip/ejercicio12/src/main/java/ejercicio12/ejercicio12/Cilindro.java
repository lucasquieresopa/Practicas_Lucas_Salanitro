package ejercicio12.ejercicio12;

public class Cilindro extends Pieza{
	
	private Integer radio;
	private Integer altura;
	private Double pi = Math.PI;
	
	public Cilindro(Integer radio, Integer altura, String color, String material) {
		this.radio = radio;
		this.altura = altura;
		super.setColor(color);
		super.setMaterial(material);
	}
	@Override
	public Double calcularVolumen() {
		
		return (this.pi * Math.pow(2, this.radio) * this.altura);
	}
	@Override
	public Double calcularSuperficie() {

		return (2 * this.pi * this.radio * this.altura + 2 * this.pi * Math.pow(2, this.radio));
	}
	public String getColor() {
		return super.getColor();
	}
	public String getMaterial() {
		return super.getMaterial();
	}

}
