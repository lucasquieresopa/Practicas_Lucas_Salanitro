package ejercicio12.ejercicio12;

public class Esfera extends Pieza{

		private Integer radio;
		private Double pi = Math.PI;

		public Esfera(Integer radio, String color, String material) {
			this.radio = radio;
			super.setColor(color);
			super.setMaterial(material);
		}
		@Override
		public Double calcularVolumen() {
			return (4/3 * this.pi * Math.pow(3, this.radio));
		}

		@Override
		public Double calcularSuperficie() {
			return (4 * this.pi * Math.pow(2, this.radio));
		}
		public String getColor() {
			return super.getColor();
		}
		public String getMaterial() {
			return super.getMaterial();
		}
}
