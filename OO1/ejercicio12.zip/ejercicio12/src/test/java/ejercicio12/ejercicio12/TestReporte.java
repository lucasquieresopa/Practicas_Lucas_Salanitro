package ejercicio12.ejercicio12;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TestReporte {

	private ReporteDeConstruccion reporte;
	private Pieza cilindro;
	private Pieza prisRect;
	private Pieza esfera;
	
	@BeforeEach
	public void setUp() {
		this.cilindro = new Cilindro(2, 4, "Rojo", "Acero");
		this.prisRect = new PrismaRectangular(3, 4, 3, "Rojo", "Vidrio");
		this.esfera = new Esfera(5, "Verde", "Vidrio");
		this.reporte = new ReporteDeConstruccion();
		this.reporte.agregarPieza(cilindro);
		this.reporte.agregarPieza(prisRect);
		this.reporte.agregarPieza(esfera);
	}
		
	@Test
	public void testCilindro() {
		assertEquals(50.265482457436691815402294132472 , this.cilindro.calcularVolumen());
		assertEquals(75.398223686155037723103441198708 , this.cilindro.calcularSuperficie());
	}
	
	@Test
	public void testPrismaRectuangular() {
//		System.out.println(this.prisRect.calcularSuperficie());
//		System.out.println(this.prisRect.calcularVolumen());
		assertTrue(this.prisRect.calcularVolumen() > 0);
		assertTrue(this.prisRect.calcularSuperficie() > 0);
	}
	
	@Test 
	public void testEsfera() {
//		System.out.println(this.esfera.calcularSuperficie());
//		System.out.println(this.esfera.calcularVolumen());
		assertTrue(this.esfera.calcularVolumen() > 0);
		assertTrue(this.esfera.calcularSuperficie() > 0);
	}
	
	@Test
	public void testSuperficie() {
		assertEquals(this.cilindro.calcularSuperficie() + this.prisRect.calcularSuperficie(), this.reporte.superficieDeColor("Rojo"));
		assertEquals(this.esfera.calcularSuperficie(), this.reporte.superficieDeColor("Verde"));
		
	}
	
	public void testVolumen() {
		assertEquals(this.cilindro.calcularVolumen(), this.reporte.volumenDeMaterial("Acero"));
		assertEquals(this.esfera.calcularVolumen() + this.prisRect.calcularVolumen(), this.reporte.volumenDeMaterial("Vidrio"));
	}
}
