package ejercicio11.ejercicio11;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.sql.Date;
import java.time.Duration;
import java.time.LocalDate;
import java.time.temporal.Temporal;
import java.util.Calendar;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TestInversiones {
	private Inversor jorge;
	
	
	@BeforeEach
	public void setUp() {
		 this.jorge = new Inversor("Jorge");
	}
	
	@Test
	public void calcularValor1() {
		Inversion invEnAcc1 = new InversionEnAcciones(1, 20);
		Inversion invEnAcc2 = new InversionEnAcciones(3, 50);
		this.jorge.agregarInversion(invEnAcc1);	
		this.jorge.agregarInversion(invEnAcc2);
		assertEquals(170.0, this.jorge.valorActual());
	}
	public void calcularValor2() {
		Calendar fecha1 = Calendar.getInstance();
		fecha1.set(Calendar.YEAR, 1999);
		fecha1.set(Calendar.MONTH, 7);
		fecha1.set(Calendar.DAY_OF_MONTH, 26);
		Calendar fecha2 = Calendar.getInstance();
		fecha2.set(Calendar.YEAR, 2002);
		fecha2.set(Calendar.MONTH, 5);
		fecha2.set(Calendar.DAY_OF_MONTH, 9);
		double monto1 = 1000.0;
		double monto2 = 6000.0;
		double porcentaje1 = 5.0;
		double porcentaje2 = 3.6;
		int dias1 = (int)Duration.between((Temporal) fecha1, LocalDate.now()).toDays();
		int dias2 = (int)Duration.between((Temporal) fecha1, LocalDate.now()).toDays();
		double calculo1 = (monto1 * Math.pow((1 + porcentaje1), dias1));
		double calculo2 = (monto2 * Math.pow((1 + porcentaje2), dias2));
		
		Inversion plazoFijo1 = new PlazoFijo(fecha1, 1000.0, 5.0);
		Inversion plazoFijo2 = new PlazoFijo(fecha2, 6000.0, 3.6);
		this.jorge.agregarInversion(plazoFijo1);	
		this.jorge.agregarInversion(plazoFijo2);
		assertEquals(calculo1 + calculo2, this.jorge.valorActual());
	}
	public void calcularValor3() {
		Calendar fecha1 = Calendar.getInstance();
		fecha1.set(Calendar.YEAR, 1999);
		fecha1.set(Calendar.MONTH, 7);
		fecha1.set(Calendar.DAY_OF_MONTH, 26);
		double monto1 = 1000.0;
		double porcentaje1 = 5.0;
		int dias1 = (int)Duration.between((Temporal) fecha1, LocalDate.now()).toDays();
		double calculo1 = (monto1 * Math.pow((1 + porcentaje1), dias1));
		Inversion plazoFijo1 = new PlazoFijo(fecha1, 1000.0, 5.0);
		this.jorge.agregarInversion(plazoFijo1);
		Inversion invEnAcc1 = new InversionEnAcciones(6, 20);
		this.jorge.agregarInversion(invEnAcc1);	
		assertEquals(calculo1 + 120.0, this.jorge.valorActual());
	}
}
