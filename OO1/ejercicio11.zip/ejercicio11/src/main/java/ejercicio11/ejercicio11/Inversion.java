package ejercicio11.ejercicio11;

public interface Inversion {
	
	public abstract double calcularValorActual();
}
