package ejercicio11.ejercicio11;

import java.util.ArrayList;
import java.util.List;

public class Inversor {
	private String nombre;
	private List<Inversion> inversiones;
	
	public Inversor(String nombre) {
		this.nombre = nombre;
		this.inversiones = new ArrayList<Inversion>();
	}
	
	public void agregarInversion(Inversion unaInversion) {
		this.inversiones.add(unaInversion);
	}
	
	public double valorActual() {
		//recorrer inversiones y devolver total
		return this.inversiones.stream()
				.mapToDouble(inversion -> inversion.calcularValorActual())
				.sum();
	}
}
