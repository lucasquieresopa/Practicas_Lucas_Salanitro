package ejercicio11.ejercicio11;

public class InversionEnAcciones implements Inversion{
	private String nombre;
	private int cantidad;
	private double valorUnitario;
	
	public InversionEnAcciones(int cantidad, double valorUnitario) {
		this.cantidad = cantidad;
		this.valorUnitario = valorUnitario;
	}
	@Override
	public double calcularValorActual() {
		return this.cantidad * this.valorUnitario;
	}
	
	
}
