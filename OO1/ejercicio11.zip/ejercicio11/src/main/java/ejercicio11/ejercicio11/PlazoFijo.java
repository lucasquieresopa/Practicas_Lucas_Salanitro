package ejercicio11.ejercicio11;

import java.time.Duration;
import java.time.LocalDate;
import java.time.temporal.Temporal;
import java.util.Calendar;
import java.util.Date;

public class PlazoFijo implements Inversion{
	private Calendar fechaDeConstitucion;
	private double montoDepositado;
	private double porcentajeDeInteresDiario;
	
	
	
	public PlazoFijo(Calendar fechaDeConstitucion, double montoDepositado, double porcentajeDeInteresDiario) {
		this.fechaDeConstitucion = fechaDeConstitucion;
		this.montoDepositado = montoDepositado;
		this.porcentajeDeInteresDiario = porcentajeDeInteresDiario;
	}

	@Override
	public double calcularValorActual() {
		//calcular recursivamente [(monto * porcentaje)*dias]
		int cantidadDeDias = (int)Duration.between((Temporal) this.fechaDeConstitucion, LocalDate.now()).toDays();
		//Calculo de interes compuesto
		return this.montoDepositado * Math.pow((1 + this.porcentajeDeInteresDiario),cantidadDeDias);
		
//		for(int i=0; i<cantidadDeDias; i++) {
//		montoTotal = montoTotal + ((this.getPorcentajeDeInteresDiario() * montoTotal) / 100);
//	}
	
	}
}
