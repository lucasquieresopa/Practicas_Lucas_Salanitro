package figurasYCuerpos.figurasYCuerpos;

public class Cuadrado implements Figura{

	private Double lado;
		
	public Cuadrado() {
		
	}
	public void setLado(Double lado) {
		this.lado = lado;
	}
	
	public Double getLado() {
		return this.lado;
	}
	
	public Double getPerimetro() {
		return this.lado * 4;
	}
	
	public Double getArea() {
		return this.lado * this.lado;
	}
}