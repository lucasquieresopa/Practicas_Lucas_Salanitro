package figurasYCuerpos.figurasYCuerpos;

public interface Figura {
	
	public Double getArea();
	
	public Double getPerimetro();
}
