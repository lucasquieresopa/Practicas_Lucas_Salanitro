package figurasYCuerpos.figurasYCuerpos; 

public class Circulo implements Figura{
	
	private Double diametro;
	private Double radio;

	public Circulo(){
		
	}
	public Double getDiametro() {
		return this.diametro;
	}
	
	public void setDiametro(Double diametro) {
		this.diametro = diametro;
	}
	
	public Double getRadio() {
		return this.radio;
	}
	
	public void setRadio(Double radio) {
		this.radio = radio;
		this.setDiametro(radio * 2);
	}
	
	public Double getPerimetro() {
		return Math.PI * this.getDiametro();
	}
	
	public Double getArea() {
		return Math.PI * Math.pow(this.getRadio(), 2);
	}
}
