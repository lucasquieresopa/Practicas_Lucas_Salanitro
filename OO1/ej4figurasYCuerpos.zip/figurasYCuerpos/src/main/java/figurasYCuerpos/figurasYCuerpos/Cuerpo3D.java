package figurasYCuerpos.figurasYCuerpos;

public class Cuerpo3D {

	private Double altura;
	private Figura caraBasal;
	
	public void setAltura(double altura) {
		this.altura = altura;
	}
	
	public Double getAltura() {
		return this.altura;
	}
	
	public void setCaraBasal(Figura caraBasal) {
		this.caraBasal = caraBasal;
		
	}
	
	public Double getVolumen() {
		return (this.caraBasal.getArea() * this.altura);
	}
	
	public Double getSuperficieExterior() {
		return ((2 * this.caraBasal.getArea()) + (this.caraBasal.getPerimetro()) * (this.altura));
	}
}
