package ejercicio9.ejercicio9;

public class CajaDeAhorro extends Cuenta{
	Double costoAdicional = 2.0;
	
	@Override
	protected Boolean puedeExtraer(Double monto) {
		//la capacidad de extraer depende de si es mayor o no al monto
		return super.getSaldo() >= monto;

	}
	
	public boolean extraer(double monto) {
		return super.extraer(monto + this.calcularCostoAdicional(monto));
	}
	
	public boolean transferirACuenta(double monto,
			Cuenta cuentaDestino) {
		return super.transferirACuenta(monto + this.calcularCostoAdicional(monto), cuentaDestino);
	}
	
	public Double calcularCostoAdicional(double monto) {
		return monto * 2 / 100;
	}
}
