package ejercicio9.ejercicio9;

public class CajaDeAhorro extends Cuenta{
	Double costoAdicional = 2.0;
	
	@Override
	protected Boolean puedeExtraer(Double monto) {
		//la capacidad de extraer depende de si es mayor o no al monto
		if(super.getSaldo() >= monto)
			return true;
		else return false;
	}
	
	public boolean extraer(double monto) {
		double montoTotal = monto + this.calcularCostoAdicional(monto);
		if(this.puedeExtraer(montoTotal)) {
			super.extraerSinControlar(monto);
			return true;
		}
		else return false;
	}
	
	public boolean transferirACuenta(double monto,
			Cuenta cuentaDestino) {
		double montoTotal = monto + this.calcularCostoAdicional(monto);
		if(this.puedeExtraer(montoTotal)) {
			super.extraerSinControlar(monto);
			cuentaDestino.depositar(monto);
			return true;
		}
		else return false;
	}
	
	public Double calcularCostoAdicional(double monto) {
		return monto * 2 / 100;
	}
}
