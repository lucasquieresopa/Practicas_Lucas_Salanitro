package ejercicio9.ejercicio9;

public class CuentaCorriente extends Cuenta{
	private Double descubierto;
	
	public CuentaCorriente() {
		this.descubierto = 0.0;
	}
	
	public Double getDescubierto() {
		return this.descubierto;
	}
	public void setDescubierto(double descubierto) {
		this.descubierto = descubierto;
	}
	protected Boolean puedeExtraer(Double monto) {
		return super.getSaldo() + this.getDescubierto() >= monto;

	}
}
