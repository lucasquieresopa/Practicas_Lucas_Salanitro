package ejercicio9.ejercicio9;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TestCuenta {
	CajaDeAhorro cajaDeAhorro;
	CuentaCorriente cuentaCorriente;
	Cuenta cuentaDestino;
	
	@BeforeEach
	public void setUp() {
		this.cajaDeAhorro = new CajaDeAhorro();
		this.cuentaCorriente = new CuentaCorriente();
		this.cuentaDestino = new CuentaCorriente();
	}
	
	@Test
	public void testValoresDeInicio() {
		assertEquals(0.0, this.cajaDeAhorro.getSaldo());
		assertEquals(0.0, this.cuentaCorriente.getSaldo());
	}
	@Test
	public void testDepositarCaja() {
		cajaDeAhorro.depositar(100.0);
		assertEquals(100.0, this.cajaDeAhorro.getSaldo());
		assertEquals(0.0, this.cuentaCorriente.getSaldo());
	}		
	@Test
	public void testExtraerCaja() {
		this.cajaDeAhorro.depositar(100.0);
		assertFalse(this.cajaDeAhorro.extraer(100.0));
		assertTrue(this.cajaDeAhorro.extraer(98.0));
	}
	@Test
	public void testTransferirCaja() {
		this.cajaDeAhorro.depositar(100.0);
		assertFalse(this.cajaDeAhorro.transferirACuenta(100.0, this.cuentaDestino));
		assertTrue(this.cajaDeAhorro.transferirACuenta(98.0, this.cuentaDestino));
	}
	@Test
	public void testPuedeExtraerCaja() {
		this.cajaDeAhorro.depositar(60);
		assertFalse(this.cajaDeAhorro.puedeExtraer(61.0));
		assertTrue(this.cajaDeAhorro.puedeExtraer(60.0));
	}
	
	
	
	@Test
	public void testDepositarCuenta() {
	cuentaCorriente.depositar(200.0);
	assertNotEquals(200.0, this.cajaDeAhorro.getSaldo());
	assertEquals(200.0, this.cuentaCorriente.getSaldo());
	}
	@Test
	public void testExtraerCuenta() {
		this.cuentaCorriente.depositar(200.0);
		assertFalse(this.cuentaCorriente.extraer(201.0));
		assertTrue(this.cuentaCorriente.extraer(200.0));
	}
	@Test
	public void testTransferirCuenta() {
		this.cuentaCorriente.depositar(200.0);
		assertTrue(this.cuentaCorriente.transferirACuenta(200, cuentaDestino));
		assertFalse(this.cuentaCorriente.transferirACuenta(201, cuentaDestino));
	}
	@Test
	public void testPuedeExtraerCuenta() {
		this.cuentaCorriente.depositar(200.0);
		assertEquals(200, this.cuentaCorriente.getSaldo());
		assertTrue(this.cuentaCorriente.puedeExtraer(200.0));
		assertFalse(this.cuentaCorriente.puedeExtraer(201.0));
	}
}
