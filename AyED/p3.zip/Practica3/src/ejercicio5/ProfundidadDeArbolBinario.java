package ejercicio5;
import ejercicio1.ArbolBinario;
import ejercicio2.ColaGenerica;
public class ProfundidadDeArbolBinario {

	ArbolBinario<Integer> arbol;
	
	public void setArbol(ArbolBinario<Integer> arbol) {
		this.arbol = arbol;
	}
	
	public int sumaElementosProfundidad(int p) {
		
		int suma_nodos = 0;
		
		ColaGenerica<ArbolBinario<Integer>> cola = new ColaGenerica<ArbolBinario<Integer>>();
    	int nivel = 0;

    	ArbolBinario<Integer> dato_cola;
    	
    	cola.encolar(arbol); //encolo este nodo
    	
    	//encolo null para determinar cambio de nivel
    	cola.encolar(null);
    	
    	//mientras haya elementos en la cola
    	while(!cola.esVacia()) {
    		
    		if(nivel <= p) {
    			
	    		//desencolo (fifo)
	    		dato_cola = cola.desencolar();
	    		if ((dato_cola != null)&(nivel == p))
	    			suma_nodos = suma_nodos + Integer.parseInt(dato_cola.toString());
	    		
	    		//si no es null, entonces es un arbol con posibles hijos
	    		if(dato_cola != null){
		    		if(dato_cola.tieneHijoIzquierdo()) {
		    			cola.encolar(dato_cola.getHijoIzquierdo());	
		    		}
		    		if(dato_cola.tieneHijoDerecho()) {
		    			cola.encolar(dato_cola.getHijoDerecho());
		    		}
	    		}
	    		//si es null, hay cambio de nivel
	    		else{
	    			
	    			nivel ++;
	    			
	    			//encolo null porque hay cambio de nivel
	    			if(!cola.esVacia()){
	    				cola.encolar(null);
	    				//System.out.println("nivel: "+(nivel-1));
	  
	    			}
	    		
	    		}
    		}
    		else
    			break;
    	}
		
		return suma_nodos;
	}
}
