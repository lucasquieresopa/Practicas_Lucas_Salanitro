package ejercicio5;

import ejercicio1.ArbolBinario;

public class prueba_ej5 {

		public static void main (String[]args) {
			
			ArbolBinario<Integer> nodo1 = new ArbolBinario<Integer>(11);
			ArbolBinario<Integer> nodo2 = new ArbolBinario<Integer>(2);
			ArbolBinario<Integer> nodo3 = new ArbolBinario<Integer>(6);
			ArbolBinario<Integer> nodo4 = new ArbolBinario<Integer>(4);
			ArbolBinario<Integer> nodo5 = new ArbolBinario<Integer>(5);
			ArbolBinario<Integer> nodo6 = new ArbolBinario<Integer>(6);
			ArbolBinario<Integer> nodo7 = new ArbolBinario<Integer>(17);
			
			nodo2.agregarHijoIzquierdo(nodo4);
			nodo2.agregarHijoDerecho(nodo5);
			
			nodo3.agregarHijoIzquierdo(nodo6);
			nodo3.agregarHijoDerecho(nodo7);
			
			nodo1.agregarHijoDerecho(nodo3);
			nodo1.agregarHijoIzquierdo(nodo2);
			
			ArbolBinario<Integer> arbol = nodo1;
			
			ProfundidadDeArbolBinario prof = new ProfundidadDeArbolBinario();
			prof.setArbol(arbol);
			
			System.out.println(prof.sumaElementosProfundidad(3));
			//System.out.println(prof.sumaElementosProfundidad(1));
			//System.out.println(prof.sumaElementosProfundidad(0));
			
		}
}
