package ejercicio2;

import ejercicio1.ArbolBinario;

public class ArbolEspejo<T> {

		ArbolBinario<T> arbol_espejo;
		
		public ArbolBinario<T> crearEspejo(ArbolBinario<T>padre, 
									ArbolBinario<T> hi, 
									ArbolBinario<T> hd){
			arbol_espejo = padre;
			arbol_espejo.agregarHijoDerecho(hd);
			arbol_espejo.agregarHijoIzquierdo(hi);
		return arbol_espejo;
		}
		
}
