package ejercicio2;

import ejercicio1.ArbolBinario;

public class Prueba {

	public static void main(String[]args) {
		
		ArbolBinario<Integer> arbol = new ArbolBinario<Integer>();
		ArbolBinario<Integer> rec = arbol;
		
		ArbolBinario<Integer> hoja;
		
		//1.1
		arbol.setDato(1);
		
		//2.1 2.2
		hoja = new ArbolBinario<Integer>(3);
		rec.agregarHijoDerecho(hoja);
		hoja = new ArbolBinario<Integer>(2);
		rec.agregarHijoIzquierdo(hoja);
		
		rec = arbol.getHijoIzquierdo();
		hoja = new ArbolBinario<Integer>(5);
		rec.agregarHijoDerecho(hoja);
		hoja = new ArbolBinario<Integer>(4);
		rec.agregarHijoIzquierdo(hoja);
		
		rec = arbol.getHijoDerecho();
		hoja = new ArbolBinario<Integer>(6);
		rec.agregarHijoIzquierdo(hoja);
		
		arbol.porNiveles();
		
	}
	
}
