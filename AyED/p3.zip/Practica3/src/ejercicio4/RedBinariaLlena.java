package ejercicio4;
import ejercicio1.ArbolBinario;

public class RedBinariaLlena {
	
	private ArbolBinario<Integer> arbol;

	
	public RedBinariaLlena(ArbolBinario<Integer> arbol) {
		this.arbol = arbol;
	}

	public int retardoReenvio() {
		int retardo_izquierdo = 0;
		int retardo_derecho = 0;
		int max;
		//recorrido en profundidad tipo postorden
		
		if(arbol.tieneHijoIzquierdo()) {
			RedBinariaLlena retardo_izq = new RedBinariaLlena(arbol.getHijoIzquierdo());
			retardo_izquierdo = retardo_izq.retardoReenvio();
		}
		if(arbol.tieneHijoDerecho()) {
			RedBinariaLlena retardo_der = new RedBinariaLlena(arbol.getHijoDerecho());
			retardo_derecho = retardo_der.retardoReenvio();
		}
		
		if(retardo_izquierdo > retardo_derecho) {
			max = retardo_izquierdo + arbol.getDato();
		}
		else {
			max = retardo_derecho + arbol.getDato();
		}
		
		System.out.println(max);
		return max;
	}
	
}
