package ejercicio4;
import ejercicio1.ArbolBinario;

public class prueba_ej4 {

	public static void main(String[]args) {
		
		ArbolBinario<Integer> nodo1 = new ArbolBinario<Integer>(4);
		ArbolBinario<Integer> nodo2 = new ArbolBinario<Integer>(4);
		ArbolBinario<Integer> nodo3 = new ArbolBinario<Integer>(4);
		ArbolBinario<Integer> nodo4 = new ArbolBinario<Integer>(1);
		ArbolBinario<Integer> nodo5 = new ArbolBinario<Integer>(5);
		ArbolBinario<Integer> nodo6 = new ArbolBinario<Integer>(6);
		ArbolBinario<Integer> nodo7 = new ArbolBinario<Integer>(0);
		ArbolBinario<Integer> nodo8 = new ArbolBinario<Integer>(7);
		ArbolBinario<Integer> nodo9 = new ArbolBinario<Integer>(2);
		ArbolBinario<Integer> nodo10 = new ArbolBinario<Integer>(3);
		ArbolBinario<Integer> nodo11 = new ArbolBinario<Integer>(9);
		ArbolBinario<Integer> nodo12 = new ArbolBinario<Integer>(6);
		ArbolBinario<Integer> nodo13 = new ArbolBinario<Integer>(1);
		ArbolBinario<Integer> nodo14 = new ArbolBinario<Integer>(5);
		ArbolBinario<Integer> nodo15 = new ArbolBinario<Integer>(5);
		
		nodo1.agregarHijoDerecho(nodo2);
		nodo1.agregarHijoIzquierdo(nodo3);
		nodo2.agregarHijoDerecho(nodo4);
		nodo2.agregarHijoIzquierdo(nodo5);
		nodo3.agregarHijoDerecho(nodo6);
		nodo3.agregarHijoIzquierdo(nodo7);
		nodo4.agregarHijoDerecho(nodo8);
		nodo4.agregarHijoIzquierdo(nodo9);
		nodo5.agregarHijoDerecho(nodo10);
		nodo5.agregarHijoIzquierdo(nodo11);
		nodo6.agregarHijoDerecho(nodo12);
		nodo6.agregarHijoIzquierdo(nodo13);
		nodo7.agregarHijoDerecho(nodo14);
		nodo7.agregarHijoIzquierdo(nodo15);
		
		RedBinariaLlena red = new RedBinariaLlena(nodo1);
		
		System.out.println("Retardo maximo: "+red.retardoReenvio()+" segundos");
		
	}
}
