package ejercicio1;
import ejercicio2.ColaGenerica;

public class ArbolBinario<T> {
	private T dato;
	private ArbolBinario<T> hijoIzquierdo;   
	private ArbolBinario<T> hijoDerecho; 

	
	public ArbolBinario() {
		super();
	}

	public ArbolBinario(T dato) {
		this.dato = dato;
	}

	/*
	 * getters y setters
	 * 
	 */
	public T getDato() {
		return dato;
	}

	public void setDato(T dato) {
		this.dato = dato;
	}
	
	/**
	 * Preguntar antes de invocar si tieneHijoIzquierdo()
	 * @return
	 */
	public ArbolBinario<T> getHijoIzquierdo() {
		return this.hijoIzquierdo;
	}

	public ArbolBinario<T> getHijoDerecho() {
		return this.hijoDerecho;

	}

	public void agregarHijoIzquierdo(ArbolBinario<T> hijo) {
		this.hijoIzquierdo = hijo;
	}

	public void agregarHijoDerecho(ArbolBinario<T> hijo) {
		this.hijoDerecho = hijo;
	}

	public void eliminarHijoIzquierdo() {
		this.hijoIzquierdo = null;
	}

	public void eliminarHijoDerecho() {
		this.hijoDerecho = null;
	}

	public boolean esVacio() {
		return this.getDato() == null && !this.tieneHijoIzquierdo() && !this.tieneHijoDerecho();
	}

	public boolean esHoja() {
		return (!this.tieneHijoIzquierdo() && !this.tieneHijoDerecho());

	}

	@Override
	public String toString() {
		return this.getDato().toString();
	}

	 
	public boolean tieneHijoIzquierdo() {
		return this.hijoIzquierdo!=null;
	}

	 
	public boolean tieneHijoDerecho() {
		return this.hijoDerecho!=null;
	}
	
	
	

	public int contarHojas() {
		Parametro total_hojas = new Parametro();
		total_hojas.setCant_hojas(0);
		
		this.recorrerySumar(total_hojas);
		//recorrer arbol y sumar si no tiene ni hi ni hd

		
		return total_hojas.getCant_hojas();
	}
	private void recorrerySumar(Parametro total_hojas){
		
		if(this.esHoja())
			total_hojas.setCant_hojas(total_hojas.getCant_hojas()+1);
		else{
			if(this.tieneHijoIzquierdo())
				this.hijoIzquierdo.recorrerySumar(total_hojas);
			if(this.tieneHijoDerecho())
				this.hijoDerecho.recorrerySumar(total_hojas);
		}
	}
	public int contarHojas2(){
		//int total_hojas = 0;
		
		if(this.esHoja())
			return 1;
		else{
			int hojas_hi= 0;
			if(this.tieneHijoIzquierdo())
				hojas_hi = this.hijoIzquierdo.contarHojas2();
			int hojas_hd= 0;
			if(this.tieneHijoDerecho())
				hojas_hd = this.hijoDerecho.contarHojas2();
			return hojas_hi + hojas_hd;
		}
	}

	
	
    public void recorridoPostOrden() {

    	if(this.tieneHijoIzquierdo() == true) {
    		//System.out.println("este es el hi: "+this.hijoIzquierdo);
    		this.hijoIzquierdo.recorridoPostOrden();
    	}
    	if(this.tieneHijoDerecho() == true) {
    		//System.out.println("este es el hd: "+this.hijoDerecho);
    		this.hijoDerecho.recorridoPostOrden();
    	}
    	System.out.println(this.getDato());
    	
    }
    
    
    
    
    public ArbolBinario<T> espejo(){
    	
    	//ao = arbol original, ae = arbol espejado
    	
    	//crea ae y asigna el dato del ao en que esta parado
	    ArbolBinario<T> arbol_espejo = new ArbolBinario<T>(this.getDato());
	    	
	    //si ao tiene hijo izquierdo, agrega a ae el hijo derecho espejado
	    if(this.tieneHijoIzquierdo())
	    	arbol_espejo.agregarHijoDerecho(this.getHijoIzquierdo().espejo());
	   
	    //si ao tiene hijo derecho, agrega a ae el hijo izquierdo espejado
	    if(this.tieneHijoDerecho())	
	    	arbol_espejo.agregarHijoIzquierdo(this.getHijoDerecho().espejo());
	    
	    //de esta manera, se iran espejando los arboles a medida que no tengan hijos
	    
	    	
    	return arbol_espejo;
    }
    
    public void porNiveles() {
    	ColaGenerica<ArbolBinario<T>> cola = new ColaGenerica<ArbolBinario<T>>();
    	int nivel = 0;
    	
    	//encolo datos o arboles?
    	
    	ArbolBinario<T> dato_cola;
    	
    	cola.encolar(this);
    	//System.out.println(this.dato);
    	
    	cola.encolar(null);
    	
    	while(!cola.esVacia()) {
    		dato_cola = cola.desencolar();
    		System.out.println(dato_cola);
    		
    		if(dato_cola != null){
    			
	    		if(dato_cola.tieneHijoIzquierdo()) {
	    			cola.encolar(dato_cola.hijoIzquierdo);
	    			
	    		}
	    		if(dato_cola.tieneHijoDerecho()) {
	    			cola.encolar(dato_cola.hijoDerecho);
	    		
	    		}

    		}
    		else{
    			
    			nivel ++;
    			
    			
    			if(!cola.esVacia()){
    				cola.encolar(null);
    				System.out.println("nivel" + nivel);
    			}
    			
    		}
    	}
    }
    	
	public void entreNiveles(int n, int m){
		
		
		
	}

	
}
