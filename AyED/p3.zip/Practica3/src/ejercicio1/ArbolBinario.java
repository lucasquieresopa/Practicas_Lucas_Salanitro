package ejercicio1;
import ejercicio2.ColaGenerica;

public class ArbolBinario<T> {
	private T dato;
	private ArbolBinario<T> hijoIzquierdo;   
	private ArbolBinario<T> hijoDerecho; 

	
	public ArbolBinario() {
		super();
	}

	public ArbolBinario(T dato) {
		this.dato = dato;
	}

	/*
	 * getters y setters
	 * 
	 */
	public T getDato() {
		return dato;
	}

	public void setDato(T dato) {
		this.dato = dato;
	}
	
	/**
	 * Preguntar antes de invocar si tieneHijoIzquierdo()
	 * @return
	 */
	public ArbolBinario<T> getHijoIzquierdo() {
		return this.hijoIzquierdo;
	}

	public ArbolBinario<T> getHijoDerecho() {
		return this.hijoDerecho;

	}

	public void agregarHijoIzquierdo(ArbolBinario<T> hijo) {
		this.hijoIzquierdo = hijo;
	}

	public void agregarHijoDerecho(ArbolBinario<T> hijo) {
		this.hijoDerecho = hijo;
	}

	public void eliminarHijoIzquierdo() {
		this.hijoIzquierdo = null;
	}

	public void eliminarHijoDerecho() {
		this.hijoDerecho = null;
	}

	public boolean esVacio() {
		return this.getDato() == null && !this.tieneHijoIzquierdo() && !this.tieneHijoDerecho();
	}

	public boolean esHoja() {
		return (!this.tieneHijoIzquierdo() && !this.tieneHijoDerecho());

	}

	@Override
	public String toString() {
		return this.getDato().toString();
	}

	 
	public boolean tieneHijoIzquierdo() {
		return this.hijoIzquierdo!=null;
	}

	 
	public boolean tieneHijoDerecho() {
		return this.hijoDerecho!=null;
	}
	
	
	

	public int contarHojas() {
		Parametro total_hojas = new Parametro();
		total_hojas.setCant_hojas(0);
		
		this.recorrerySumar(total_hojas);
		//recorrer arbol y sumar si no tiene ni hi ni hd

		
		return total_hojas.getCant_hojas();
	}
	private void recorrerySumar(Parametro total_hojas){
		
		if(this.esHoja())
			total_hojas.setCant_hojas(total_hojas.getCant_hojas()+1);
		else{
			if(this.tieneHijoIzquierdo())
				this.hijoIzquierdo.recorrerySumar(total_hojas);
			if(this.tieneHijoDerecho())
				this.hijoDerecho.recorrerySumar(total_hojas);
		}
	}
	public int contarHojas2(){
		//int total_hojas = 0;
		
		if(this.esHoja())
			return 1;
		else{
			int hojas_hi= 0;
			if(this.tieneHijoIzquierdo())
				hojas_hi = this.hijoIzquierdo.contarHojas2();
			int hojas_hd= 0;
			if(this.tieneHijoDerecho())
				hojas_hd = this.hijoDerecho.contarHojas2();
			return hojas_hi + hojas_hd;
		}
	}

	
	
    public void recorridoPostOrden() {

    	if(this.tieneHijoIzquierdo() == true) {
    		//System.out.println("este es el hi: "+this.hijoIzquierdo);
    		this.hijoIzquierdo.recorridoPostOrden();
    	}
    	if(this.tieneHijoDerecho() == true) {
    		//System.out.println("este es el hd: "+this.hijoDerecho);
    		this.hijoDerecho.recorridoPostOrden();
    	}
    	System.out.println(this.getDato());
    	
    }
    
    
    
    
    public ArbolBinario<T> espejo(){
    	
    	//Crea arbol espejo, llama a crearEspejo y devuelve el arbol compelto;
    	
    	//arbol que se devuelve:
	    ArbolBinario<T> arbol_espejo = new ArbolBinario<T>();
	    
	    	arbol_espejo = this.crearEspejo(arbol_espejo);
	    	
    	return arbol_espejo;
    }
    private ArbolBinario<T> crearEspejo(ArbolBinario<T> hijos_invertidos){
    	
    	//si es hoja no hace nada, si no es, es que es padre
    	//si es padre, se inserta en el arbol creado vacio e intercambia los hijos
    	//el padre anterior adopta a este como uno de sus hijos
    	
    	if(!this.esHoja()) {
	    	if(this.tieneHijoIzquierdo()) 
	    		this.hijoIzquierdo.crearEspejo(hijos_invertidos);
	    	
	    	if(this.tieneHijoDerecho()) 
	    		this.hijoDerecho.crearEspejo(hijos_invertidos);

	    	
	    	hijos_invertidos.setDato(this.getDato());
	    	hijos_invertidos.agregarHijoDerecho(this.hijoIzquierdo);
	    	hijos_invertidos.agregarHijoIzquierdo(this.hijoDerecho);
    	}
    	return hijos_invertidos;
    }
    
    
    public void porNiveles() {
    	ColaGenerica<ArbolBinario<T>> cola = new ColaGenerica<ArbolBinario<T>>();

    	
    	//encolo datos o arboles?
    	
    	ArbolBinario<T> dato_cola;
    	
    	cola.encolar(this);
    	System.out.println(this.dato);
    	while(!cola.esVacia()) {
    		dato_cola = cola.desencolar();
    		System.out.println(dato_cola);
    		if(dato_cola.tieneHijoIzquierdo()) {
    			cola.encolar(this.hijoIzquierdo);
    			//System.out.println(this.hijoIzquierdo);
    		}
    		if(dato_cola.tieneHijoDerecho()) {
    			cola.encolar(this.hijoDerecho);
    			//System.out.println(this.hijoDerecho);
    		}
    	}
    	
    }
    	
	public void entreNiveles(int n, int m){
		
		
		
	}

	
}
