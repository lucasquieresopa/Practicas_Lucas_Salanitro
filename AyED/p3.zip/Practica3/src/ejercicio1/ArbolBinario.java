package ejercicio1;

public class ArbolBinario<T> {
	private T dato;
	private ArbolBinario<T> hijoIzquierdo;   
	private ArbolBinario<T> hijoDerecho; 

	
	public ArbolBinario() {
		super();
	}

	public ArbolBinario(T dato) {
		this.dato = dato;
	}

	/*
	 * getters y setters
	 * 
	 */
	public T getDato() {
		return dato;
	}

	public void setDato(T dato) {
		this.dato = dato;
	}
	
	/**
	 * Preguntar antes de invocar si tieneHijoIzquierdo()
	 * @return
	 */
	public ArbolBinario<T> getHijoIzquierdo() {
		return this.hijoIzquierdo;
	}

	public ArbolBinario<T> getHijoDerecho() {
		return this.hijoDerecho;

	}

	public void agregarHijoIzquierdo(ArbolBinario<T> hijo) {
		this.hijoIzquierdo = hijo;
	}

	public void agregarHijoDerecho(ArbolBinario<T> hijo) {
		this.hijoDerecho = hijo;
	}

	public void eliminarHijoIzquierdo() {
		this.hijoIzquierdo = null;
	}

	public void eliminarHijoDerecho() {
		this.hijoDerecho = null;
	}

	public boolean esVacio() {
		return this.getDato() == null && !this.tieneHijoIzquierdo() && !this.tieneHijoDerecho();
	}

	public boolean esHoja() {
		return (!this.tieneHijoIzquierdo() && !this.tieneHijoDerecho());

	}

	@Override
	public String toString() {
		return this.getDato().toString();
	}

	 
	public boolean tieneHijoIzquierdo() {
		return this.hijoIzquierdo!=null;
	}

	 
	public boolean tieneHijoDerecho() {
		return this.hijoDerecho!=null;
	}

	public int contarHojas() {
		int total_hojas = 0;
		
		if (this.getHijoDerecho() != null){
			total_hojas++;
		}
		if (this.getHijoIzquierdo() != null){
			total_hojas++;
		}
		
		return total_hojas;
	}
	

    public ArbolBinario<T> espejo() {
		ArbolBinario<T> arbol_espejo = new ArbolBinario<T>();
    	
		//auxiliar para guardar hoja
		T aux;
		//auxiliar para recorrer, arbol == raiz
		ArbolBinario<T> actual = arbol;
		ArbolBinario<T> anterior;
		
		//si tiene hi llamar hasta llegar a null
		if (this.getHijoIzquierdo() != null) 
			anterior = actual;
			actual.espejo(actual.getHijoIzquierdo());
		}
		
		//si hay hi tomarlo
    	if 
		aux = anterior.getHijoIzquierdo();
    	
		return arbol_espejo;
	}

	/*
	ir al nodo de mas a la izquierda y luego al de mas a la derecha
	una vez en el final, intercambiar izq, aux y der
	al ir volviendo en los niveles, hacer lo mismo
	hacer el intercambio por niveles? primero el mas bajo, hasta llegar a la raiz
	*/
	public void entreNiveles(int n, int m){
		
	}

	

}
