package ejercicio1;

public class Parametro {

	int cant_hojas;

	public int getCant_hojas() {
		return cant_hojas;
	}

	public void setCant_hojas(int cant_hojas) {
		this.cant_hojas = cant_hojas;
	}
	
	
}
