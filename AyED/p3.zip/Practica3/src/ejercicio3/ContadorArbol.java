package ejercicio3;
import ejercicio2.*;
import ejercicio1.ArbolBinario;
public class ContadorArbol {

	private ArbolBinario<Integer> arbol;



	public void setArbol(ArbolBinario<Integer> arbol) {
		this.arbol = arbol;
	}
	

	
	public ListaGenerica<Integer> numerosParesInorden(){
	
		ListaGenerica<Integer> lista_pares = new ListaEnlazadaGenerica<Integer>();
		this.numerosParesInordenRec(arbol, lista_pares);
		return lista_pares;
	}
	
	

	private void numerosParesInordenRec(ArbolBinario<Integer> arbol, ListaGenerica<Integer> lista_pares){
		
		if(arbol.tieneHijoIzquierdo()) 
			this.numerosParesInordenRec(arbol.getHijoIzquierdo(), lista_pares);
		if(arbol.getDato() % 2 == 0)
			lista_pares.agregarFinal(arbol.getDato());	

		if(arbol.tieneHijoDerecho())
			this.numerosParesInordenRec(arbol.getHijoDerecho(), lista_pares);
	}

	public ListaGenerica<Integer> numerosParesPostorden(){
		
		ListaGenerica<Integer> lista_pares = new ListaEnlazadaGenerica<Integer>();
		this.numerosParesPostordenRec(arbol,lista_pares);
		return lista_pares;
	}
	
	

	private void numerosParesPostordenRec(ArbolBinario<Integer> arbol,ListaGenerica<Integer> lista_pares){
		
		if(arbol.tieneHijoIzquierdo())
			this.numerosParesPostordenRec(arbol.getHijoIzquierdo(),lista_pares);
		
		if(arbol.tieneHijoDerecho()) 
			this.numerosParesPostordenRec(arbol.getHijoDerecho(),lista_pares);
	
		if(arbol.getDato() % 2 == 0)
			lista_pares.agregarFinal(arbol.getDato());	
	}
}
