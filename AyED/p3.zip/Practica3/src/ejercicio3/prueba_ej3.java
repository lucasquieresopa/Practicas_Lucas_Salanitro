package ejercicio3;
import ejercicio1.ArbolBinario;
import ejercicio2.*;
public class prueba_ej3 {

		public static void main(String[]args) {
			
			ArbolBinario<Integer> nodo1 = new ArbolBinario<Integer>(1);
			ArbolBinario<Integer> nodo2 = new ArbolBinario<Integer>(2);
			ArbolBinario<Integer> nodo3 = new ArbolBinario<Integer>(3);
			ArbolBinario<Integer> nodo4 = new ArbolBinario<Integer>(4);
			ArbolBinario<Integer> nodo5 = new ArbolBinario<Integer>(5);
			ArbolBinario<Integer> nodo6 = new ArbolBinario<Integer>(6);
			ArbolBinario<Integer> nodo7 = new ArbolBinario<Integer>(7);
			
			
			nodo1.agregarHijoIzquierdo(nodo2);
			nodo1.agregarHijoDerecho(nodo3);
			
			nodo2.agregarHijoIzquierdo(nodo4);
			nodo2.agregarHijoDerecho(nodo5);
			
			nodo3.agregarHijoIzquierdo(nodo6);
			nodo3.agregarHijoDerecho(nodo7);

			
			
			ContadorArbol pares = new ContadorArbol();
			
			ListaGenerica<Integer> lista_pares = new ListaEnlazadaGenerica<Integer>();	
			
			ArbolBinario<Integer> arbol = nodo1;
			pares.setArbol(arbol);
			
			
			lista_pares = pares.numerosParesInorden();
			System.out.println("------------------INORDEN------------------");
			for (int i=0; i < lista_pares.tamanio(); i++) {
				System.out.println(lista_pares.proximo());
			}
			
			
			
			lista_pares.comenzar();
			lista_pares = pares.numerosParesPostorden();
			
			System.out.println("------------------POSTORDEN------------------");
			for (int i=0; i < lista_pares.tamanio(); i++) {
				System.out.println(lista_pares.proximo());
			}
		}
}
