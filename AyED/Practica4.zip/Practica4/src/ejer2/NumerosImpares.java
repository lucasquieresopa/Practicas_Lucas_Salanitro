package ejer2;

import tp02.ejercicio2.ListaEnlazadaGenerica;
import tp02.ejercicio2.ListaGenerica;
import tp04.ejercicio1.ArbolGeneral;

/* esta clase surge a partir de un error en la practica que pide que se utilicen valores
 * tipo Integer, sin embargo los arboles son de tipo T. Las dos soluciones son 
 * parsear a Integer esos datos T dentro de la clase ArbolGeneral, o crear una 
 * nueva clase que realice esos metodos pedidos y use un metodo de instancia tipo ArbolGeneral<Integer>
 */

public class NumerosImpares {

	private ArbolGeneral<Integer> a;
	
	public NumerosImpares(ArbolGeneral<Integer> unArbol) {
		this.a = unArbol;
	}
	
	public ListaGenerica<Integer> numerosImparesMayoresQuePreOrden (Integer n) {
		
		ListaGenerica<Integer> impares_preOrden = new ListaEnlazadaGenerica<Integer>();
		
		return impares_preOrden;
	}
	
	public ListaGenerica<Integer> numerosImparesMayoresQueInOrden (Integer n){
		
		ListaGenerica<Integer> impares_inOrden = new ListaEnlazadaGenerica<Integer>();
		
		return impares_inOrden;
	}
	
	public ListaGenerica<Integer> numerosImparesMayoresQuePostOrden (Integer n){
		
		ListaGenerica<Integer> impares_postOrden = new ListaEnlazadaGenerica<Integer>();
		
		return impares_postOrden;
	}
	
	public ListaGenerica<Integer> numerosImparesMayoresQuePorNiveles(){
		
		ListaGenerica<Integer> impares_porNiveles = new ListaEnlazadaGenerica<Integer>();
		
		return impares_porNiveles;
	}
}
