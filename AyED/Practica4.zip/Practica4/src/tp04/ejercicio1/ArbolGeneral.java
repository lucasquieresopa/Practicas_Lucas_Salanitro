package tp04.ejercicio1;

import tp02.ejercicio2.ListaEnlazadaGenerica;
import tp02.ejercicio2.ListaGenerica;

public class ArbolGeneral<T> {

	private T dato;

	private ListaGenerica<ArbolGeneral<T>> hijos = new ListaEnlazadaGenerica<ArbolGeneral<T>>();

	public T getDato() {
		return dato;
		//devuelve el dato (tipo T) almacenado en un nodo(tipo ArbolGeneral)
	}

	public void setDato(T dato) {
		this.dato = dato;
	}

	public void setHijos(ListaGenerica<ArbolGeneral<T>> hijos) {
		if (hijos==null)
			this.hijos = new ListaEnlazadaGenerica<ArbolGeneral<T>>();
		//si la lista de hijos recibida es vacia, crea una lista(vacia) y la asigna como variable de clase "hijos"(
		else
			this.hijos = hijos;
		//si la lista recibida tiene elementos, asigna la lista como variable de clase "hijos"
	}

	public ArbolGeneral(T dato) {
		this.dato = dato;
		//constructor solo raiz
	}

	public ArbolGeneral(T dato, ListaGenerica<ArbolGeneral<T>> hijos) {
		this(dato);
		if (hijos==null)
			this.hijos = new ListaEnlazadaGenerica<ArbolGeneral<T>>();
		else
			this.hijos = hijos;
		//constructor de raiz + hijos (la asignacion de los hijos es igual a setHijos())
	}

	public ListaGenerica<ArbolGeneral<T>> getHijos() {
		return this.hijos;
		//devuelve una lista proveniente de la variable de clase "hijos"
	}

	public void agregarHijo(ArbolGeneral<T> unHijo) {

		this.getHijos().agregarFinal(unHijo);
		//agrega un elemento (tipo ArbolGeneral<T>)al final de la lista de hijos
	}

	public boolean esHoja() {

		return !this.tieneHijos();
		//es hoja si no tiene hijos, pero si tiene dato
	}
	
	public boolean tieneHijos() {
		return !this.hijos.esVacia();
		//tiene hijos si la var de clase hijos no esta vacia
	}
	
	public boolean esVacio() {

		return this.dato == null && !this.tieneHijos();
		//es vacio si no tiene hijos ni datos
	}

	

	public void eliminarHijo(ArbolGeneral<T> hijo) {
		if (this.tieneHijos()) {
			ListaGenerica<ArbolGeneral<T>> hijos = this.getHijos();
			if (hijos.incluye(hijo)) 
				hijos.eliminar(hijo);
		}
	}
	
	public ListaEnlazadaGenerica<T> preOrden() {
		return null;
	}
	
	public Integer altura() {
		// Falta implementar..
		return 0;
	}

	public Integer nivel(T dato) {
		// falta implementar
		return -1;
	}

	public Integer ancho() {
		// Falta implementar..
		return 0;
	}
	
	public ListaGenerica<T> numerosImparesMayoresQuePreOrden(Integer n){
		
		
		//ListaGenerica<T> lista_impares = new ListaEnlazadaGenerica<T>();
		
		//if(!this.esVacio() && this.getDato() instanceof Number) {
			//Integer dato = (Integer)this.getDato();
		
			
		
		return lista_impares;
	}
	
	
	
	
	
}