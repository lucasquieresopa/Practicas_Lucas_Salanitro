package ejer4;

public class Numerica {

	int altura_actual = -1;
	boolean encontre = false;

	public int getAltura_actual() {
		return altura_actual;
	}

	public void setAltura_actual(int altura_actual) {
		this.altura_actual = altura_actual;
	}
	public boolean getEncontre() {
		return encontre;
	}
	public void setEncontre(boolean encontre) {
		this.encontre = encontre;
	}
	
}
