module Practica6 {
}