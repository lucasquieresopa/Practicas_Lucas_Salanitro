package tp06.ejercicio3;

import tp02.ejercicio2.ListaEnlazadaGenerica;
import tp02.ejercicio2.ListaGenerica;

public class VerticeImplListAdy<T>implements Vertice<T> {
    private T dato;
    private int posicion;
    private ListaGenerica<Arista<T>> adyacentes;

    public VerticeImplListAdy(T d) {
        dato = d;
        adyacentes = new ListaEnlazadaGenerica<Arista<T>>();
    }

    @Override
    public T dato() {
        return this.dato;
    }

    @Override
    public void setDato(T dato) {
        this.dato = dato;
    }
    public void setPosicion(int pos) {
        posicion = pos;
    }
    @Override
    public int getPosicion() {
        return posicion;
    }

    public ListaGenerica<Arista<T>> obtenerAdyacentes() {
        return adyacentes;
    }

    public void conectar(Vertice<T> v) {
        conectar(v, 1);
    }

    public void conectar(Vertice<T> v, int peso) {
    	//si no hay una arista conectada al vertice previamente, se crea una y se agrega al final de la lista

    	Arista<T> arista = obtenerArista(v);

        if (arista == null) {
            Arista<T> a = new AristaImpl<T>(v, peso);
            adyacentes.agregarFinal(a);
        }
    }

    public void desconectar(Vertice<T> v) {
    	//si existe conexion de la arista con el vertice, se elimina la arista
        Arista<T> arista = obtenerArista(v);

        if (arista != null) {
            adyacentes.eliminar(arista);
        }
    }

    public boolean esAdyacente(Vertice<T> v) {
    	//devuelve True si el vertice existe en la lista de adyacentes, y False si no
        Arista<T> arista = obtenerArista(v);

        return arista != null;
    }

    public int peso(Vertice<T> v) {
    	//devuleve el valor de la arista(peso) conectada al vertice si existe la union, si no devuelve 0
        Arista<T> arista = obtenerArista(v);

        int ret = 0;
        if (arista != null) {
            ret = arista.peso();
        }

        return ret;
    }

    private Arista<T> obtenerArista(Vertice<T> v) {
    	//devuelve null si no se halla el vertice a conecta en ninguna arista, y la arista si existe
        Arista<T> arista = null;
        Arista<T> aristaAux;
        adyacentes.comenzar();
        while (!adyacentes.fin()) {
            aristaAux = adyacentes.proximo();
            if (aristaAux.verticeDestino() == v) {
                arista = aristaAux;
            }
        }
        return arista;
    }

    

}
