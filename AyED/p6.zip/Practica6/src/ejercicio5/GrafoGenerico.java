package ejercicio5;
import tp06.ejercicio3.*;
import tp02.ejercicio2.*;

public class GrafoGenerico {

	
	public static void main(String[]args) {
		
		//instancio grafos para imprimir recorridos
		
		Grafo<Integer> grafo = new GrafoImplListAdy<Integer>();
		
		VerticeImplListAdy<Integer> vert1 = new VerticeImplListAdy<Integer>(1);
		VerticeImplListAdy<Integer> vert2 = new VerticeImplListAdy<Integer>(2);
		VerticeImplListAdy<Integer> vert3 = new VerticeImplListAdy<Integer>(3);
		VerticeImplListAdy<Integer> vert4 = new VerticeImplListAdy<Integer>(4);
		VerticeImplListAdy<Integer> vert5 = new VerticeImplListAdy<Integer>(5);
		VerticeImplListAdy<Integer> vert6 = new VerticeImplListAdy<Integer>(6);
		VerticeImplListAdy<Integer> vert7 = new VerticeImplListAdy<Integer>(7);
	
		grafo.agregarVertice(vert1);
		grafo.agregarVertice(vert2);
		grafo.agregarVertice(vert3);
		grafo.agregarVertice(vert4);
		grafo.agregarVertice(vert5);
		grafo.agregarVertice(vert6);
		grafo.agregarVertice(vert7);
		
		grafo.conectar(vert1, vert2);
		grafo.conectar(vert1, vert3);
		grafo.conectar(vert1, vert4);
		grafo.conectar(vert2, vert5);
		grafo.conectar(vert5, vert5);
		grafo.conectar(vert3, vert2);
		grafo.conectar(vert3, vert6);
		grafo.conectar(vert3, vert7);
		grafo.conectar(vert6, vert3);
		grafo.conectar(vert4, vert7);
		grafo.conectar(vert7, vert6);
		
		System.out.println("GRAFO DFS");
		Recorridos<Integer> rec = new Recorridos<Integer>();
		ListaGenerica<Vertice<Integer>> lista = rec.bfs(grafo);
		lista.comenzar();
		while(!lista.fin()) {
			System.out.println(lista.proximo().dato());
		}
		System.out.println("GRAFO BFS");
		ListaGenerica<Vertice<Integer>> lista2 = rec.dfs(grafo);
		lista2.comenzar();
		while(!lista2.fin()) {
			System.out.println(lista2.proximo().dato());
		}
		
		
		
	}
	
}
