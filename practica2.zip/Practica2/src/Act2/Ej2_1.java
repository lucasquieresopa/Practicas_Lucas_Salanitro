package Act2;
import tp02.ejercicio1.*;
public class Ej2_1 {

	public static void main(String[]args) {
		
		ListaDeEnteros<ListaDeEnterosEnlazada> lista1 = new ListaDeEnteros<ListaDeEnterosEnlazada>();
	}
}
