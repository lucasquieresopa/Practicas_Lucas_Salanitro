package ejercicio13.ejercicio13;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TestClienteDeCorreo {
	private ClienteDeCorreo cliente;
	private Carpeta carpeta, carpeta2;
	private Email email, email2, email3;
	
	@BeforeEach
	public void setUp() {
		this.email=new Email("Titulo1", "Cuerpo1");
		this.email2=new Email("Titulo2", "Cuerpo2");
		this.email3=new Email("Titulo3", "Cuerpo3");
		this.email.agregarAdjunto(new Archivo("Nombre1"));
		this.email.agregarAdjunto(new Archivo("Nombre2"));
		this.email2.agregarAdjunto(new Archivo("NombreNombre"));
		this.email3.agregarAdjunto(new Archivo("Nombre3"));
		
		this.carpeta=new Carpeta("Carpeta1");
		this.carpeta.almacenar(email);
		this.carpeta.almacenar(email2);
		
		this.carpeta2=new Carpeta("Carpeta2");
		this.carpeta2.almacenar(email3);
		
		this.cliente=new ClienteDeCorreo();
		this.cliente.agregarCarpeta(carpeta);
		this.cliente.agregarCarpeta(carpeta2);
	}
	
	@Test
	public void testRecibir() {
		Email inbox = new Email("Inbox", "Inbox");
		this.cliente.recibir(inbox);
		assertTrue(this.cliente.getInbox().getEmails().contains(inbox));
	}
	
	@Test
	public void testMover() {
		this.cliente.mover(email2, carpeta, carpeta2);
		assertTrue(this.carpeta2.getEmails().contains(email2));
		assertFalse(this.carpeta.getEmails().contains(email2));
	}
	
	@Test
	public void testBuscar() {
		assertEquals(email3, this.cliente.buscar("Cuerpo3"));
	}
	
	@Test
	public void testEspacio() {
		assertEquals(33, this.cliente.espacioOcupado());
	}
	
	
}
