package ejercicio13.ejercicio13;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TestCarpeta {
	private Carpeta carpeta;
	private Email email, email2;
	
	@BeforeEach
	public void setUp() {
		this.email=new Email("Titulo1", "Cuerpo1");
		this.email2=new Email("Titulo2", "Cuerpo2");
		this.email.agregarAdjunto(new Archivo("Nombre1"));
		this.email.agregarAdjunto(new Archivo("Nombre2"));
		this.email2.agregarAdjunto(new Archivo("NombreNombre"));
		
		this.carpeta=new Carpeta("Carpeta1");
		this.carpeta.almacenar(email);
		this.carpeta.almacenar(email2);
	}
	
	@Test
	public void testEspacio() {
		assertEquals(26, this.carpeta.espacioOcupado());
		assertEquals(2, this.carpeta.getEmails().size());
	}
	
	@Test
	public void testAgregarQuitar() {
		this.carpeta.almacenar(new Email("Titulo3", "Cuerpo3"));
		assertEquals(3, this.carpeta.getEmails().size());
		this.carpeta.remover(email);
		assertFalse(this.carpeta.getEmails().contains(email));
	}
	
	@Test 
	public void testBuscar() {
		assertEquals(email2, this.carpeta.buscarEnEmail("Cuerpo2"));
	}
}

//problema con testBuscar
