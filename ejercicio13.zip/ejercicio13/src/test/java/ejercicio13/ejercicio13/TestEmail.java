package ejercicio13.ejercicio13;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TestEmail {

	private Email email;
//	private String texto = "Nombre1";
//	private String texto2 = "Nombre2";
//	private String texto3 = "NombreNombre";
	
	@BeforeEach
	public void setUp() {
		this.email=new Email("Titulo1", "Cuerpo1");
		this.email.agregarAdjunto(new Archivo("Nombre1"));
		this.email.agregarAdjunto(new Archivo("Nombre2"));
		this.email.agregarAdjunto(new Archivo("NombreNombre"));
	}
	
	@Test
	public void testEmail() {
		//System.out.println("Valor1 " + this.texto.length() + " / Valor2 " + this.texto2.length() + " / Valor3 " + this.texto3.length());
		//System.out.println(this.texto.length() + this.texto2.length() + this.texto3.length());
		assertTrue(this.email.espacioOcupado().getClass().getSimpleName().equals("Integer"));
		assertEquals(26, this.email.espacioOcupado());
	}
}
