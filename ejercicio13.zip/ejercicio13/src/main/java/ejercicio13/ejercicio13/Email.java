package ejercicio13.ejercicio13;

import java.util.ArrayList;
import java.util.List;

public class Email {
	
	private String titulo;
	private String cuerpo;
	private List<Archivo> adjuntos;
	
	
	public String getTitulo() {
		return this.titulo;
	}
	public String getCuerpo(){
		return this.cuerpo;
	}
	public List<Archivo> adjuntos() {
		return this.adjuntos;
	}
	public Integer espacioOcupado() {
		//Devuelve la suma de los espacios de todos los archivos
		return (int) this.adjuntos.stream()
				.mapToDouble(archivo -> archivo.tamaño())
				.sum();
	}
	
	public boolean hallarTexto(String texto) {
		return (this.getTitulo().contains(texto) || (this.getCuerpo().contains(texto)));

	}
	
	//metodos agregados para testear
	public Email(String titulo, String cuerpo) {
		this.titulo=titulo;
		this.cuerpo=cuerpo;
		this.adjuntos=new ArrayList<Archivo>();
	}
	public void agregarAdjunto(Archivo archivo) {
		this.adjuntos.add(archivo);
	}

}
