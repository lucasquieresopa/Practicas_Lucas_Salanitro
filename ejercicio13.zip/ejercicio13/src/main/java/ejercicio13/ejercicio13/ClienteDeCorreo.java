package ejercicio13.ejercicio13;

import java.util.ArrayList;
import java.util.List;

public class ClienteDeCorreo {
	private Carpeta inbox;
	private List<Carpeta> carpetas;
	
	public ClienteDeCorreo() {
		this.carpetas= new ArrayList<Carpeta>();
		this.inbox=new Carpeta("Inbox");
	}
	
	public void recibir(Email email) {
		this.inbox.almacenar(email);
	}
	public void mover(Email email, Carpeta origen, Carpeta destino) {
		//quita el email de la carpeta origen removiendolo de
		//la lista de emails que posee carpeta y lo agrega a la
		//lista de emails de la carpeta destino
		origen.remover(email);
		destino.almacenar(email);
	}
	
	public Email buscar(String texto) {

		return this.carpetas.stream()
				.map(carpeta -> carpeta.buscarEnEmail(texto))
				.filter(email -> email!=null)
				.findFirst()
				.orElse(null);
	}

	
	public Integer espacioOcupado() {
		//para c/carpeta sumar espacios
		
		return this.carpetas.stream()
				.mapToInt(carpeta -> carpeta.espacioOcupado())
				.sum();
	}
	
	
	//metodos implementados para test
	public Carpeta getInbox() {
		return this.inbox;
	}
	public void agregarCarpeta(Carpeta carpeta) {
		this.carpetas.add(carpeta);
	}
}
