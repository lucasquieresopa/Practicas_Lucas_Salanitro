package ejercicio5;
import tp02.ejercicio2.ListaGenerica;
import tp02.ejercicio2.ColaGenerica;
import tp02.ejercicio2.ListaEnlazadaGenerica;
import tp06.ejercicio3.Arista;
import tp06.ejercicio3.Grafo;
import tp06.ejercicio3.Vertice;

public class Recorridos<T> {

	
	
	private void dfs(Grafo<T> grafo, ListaGenerica<Vertice<T>> vertices_dfs, boolean[] marcas, int indice) {
		
		//marco en el arreglo de booleanos la posicion(correspondiente a un vertice)recibida
		//determina que ya fue visitado
		marcas[indice] = true;
		
		//creo vertice que toma valor del elemento correspondiente a la posicion que indica el indice en la lista de vertices del grafo
		Vertice<T> v = grafo.listaDeVertices().elemento(indice);
		vertices_dfs.agregarFinal(v);
		
		//tomo adyacentes del vertice tomado del grafo (v)
		//la lista contiene aristas porque son las que determinan a donde apunta un vertice
		ListaGenerica<Arista<T>> adyacentes = grafo.listaDeAdyacentes(v);
		
		//para cada adyacente, hago dfs si no fue visitado (marcas[inidice del adyacente] == false)
		adyacentes.comenzar();
		while(!adyacentes.fin()) {
			//tomo el indice del adyacente que le sigue para poder accederlo en la siguiente recursion
			int indice2 = adyacentes.proximo().verticeDestino().getPosicion();
			if(!marcas[indice2]) {
				dfs(grafo, vertices_dfs, marcas, indice2);
			}
		}
	}
	
	//dfs(Grafo<T> grafo): ListaGenerica <T>
	public ListaGenerica<Vertice<T>> dfs(Grafo<T> grafo){
		//matriz que contendra informacion de vertices (F: no recorrido, T: recorrido)
		//se incrementa en 1 pero no se usa la pos. 0
		boolean[] marcasAdy = new boolean[(grafo.listaDeVertices().tamanio())+1];
		
		//inicializo todas las marcas en falso para determinar que los vertices no fueron visitados
		//for (int i=1; i<marcasAdy.length; i++) {
			
		for (int i=1; i<=grafo.listaDeVertices().tamanio(); i++) {
			marcasAdy[i]=false;
		}
		//lista con vertices ordenados por el recorrido
		ListaEnlazadaGenerica<Vertice<T>> vertices_dfs = new ListaEnlazadaGenerica<Vertice<T>>();
		
		//recorrer cada vertice(posicion en la matriz) y hacer dfs si no esta marcado(no fue visitado)
		//for(int i=1; i<marcasAdy.length; i++) {
		
		for (int i=1; i<=grafo.listaDeVertices().tamanio(); i++) {
			if(!marcasAdy[i]) {
				dfs(grafo, vertices_dfs, marcasAdy, i);
				//envio el grafo para acceder a sus metodos, la lista para cargarla
				//el arreglo de booleanos y el indice para marcar como visitado
			}
			
		}	
		return vertices_dfs;
	}
	
	
	
	
	
	
	//probablemente falta la inicializacion de la lista de adyacentes en null
	private void bfs(Grafo<T> grafo, ListaEnlazadaGenerica<Vertice<T>> vertices_bfs, boolean[] marcasAdy, int indice) {
		//creo cola
		ColaGenerica<Vertice<T>> cola = new ColaGenerica<Vertice<T>>();
		
		//encolo vertice origen y lo marco
		cola.encolar(grafo.listaDeVertices().elemento(indice));
		marcasAdy[indice] = true;
		
		//mientras haya elementos en la cola, desencolo y encolo sus adyacentes
		while(!cola.esVacia()) {
			
			//desencola v para tomar sus adyacentes
			Vertice<T> v = cola.desencolar();
			vertices_bfs.agregarFinal(v);
			//tomo adyacentes del vertice tomado de la cola (v)
			//la lista contiene aristas porque son las que determinan a donde apunta un vertice
			ListaGenerica<Arista<T>> adyacentes = grafo.listaDeAdyacentes(v);
			
			adyacentes.comenzar();
			//mientras existan adyacentes
			while(!adyacentes.fin()) {
				/*
				//doy a var indice el valor del siguiente adyacente
				indice = adyacentes.proximo().verticeDestino().getPosicion();
				
				//si no esta marcado, lo encolo y lo marco
				if(marcasAdy[indice]==false) {
					cola.encolar(grafo.listaDeVertices().elemento(indice));
					marcasAdy[indice] = true;
				}
				*/
				
				//tomo arista para tomar la posicion del vertice al que apunta
				Arista<T> arista = adyacentes.proximo();
				int indice2 = arista.verticeDestino().getPosicion();
				
				//si no esta marcado, lo marco y encolo el vertice al que apunta
				if(!marcasAdy[indice2]) {
					Vertice<T> dest = arista.verticeDestino();
					marcasAdy[indice2] = true;
					cola.encolar(dest);
				}
				
			}	
		}
		
	}

	
	//bfs(Grafo<T> grafo): ListaGenerica <T>
	public ListaGenerica<Vertice<T>> bfs(Grafo<T> grafo){
		
		//creo arreglo de booleanos que determina si un vertice fue recorrido(True) o no(False)
		boolean[] marcasAdy = new boolean[(grafo.listaDeVertices().tamanio()) + 1];
		
		//inicializo cada pos del arreglo de booleanos en false
		for(int i = 1; i < grafo.listaDeVertices().tamanio(); i++) {
			marcasAdy[i] = false;
		}
		
		//creo lista que contendra el recorrido en bfs
		ListaEnlazadaGenerica<Vertice<T>> vertices_bfs = new ListaEnlazadaGenerica<Vertice<T>>();
		
		for (int i=1; i<=grafo.listaDeVertices().tamanio(); i++) {
			if (!marcasAdy[i])
				bfs(grafo,vertices_bfs,marcasAdy,i);
		}
		return vertices_bfs;
	}
}

		
	
