package parc;
import tp02.ejercicio2.*;
import tp06.ejercicio3.*;

public class Parc1<T> {
	private Grafo<T> bosque; 
	
	/* el enunciado dice que hay que devolver todos los caminos posibles
	 * desde un vertice A a otro B en los que las aristas tienen peso
	 * y no se permite pasar por aquellas mayores a ese peso (en el
	 * caso de este ejemplo, no se permite pasar por las mayores a 5)*/
	
	private void dfs(Vertice<T> v, ListaGenerica<T> caminoAct,  boolean[] marca,
			ListaGenerica<ListaGenerica<T>> result) {
		
		ListaGenerica<Arista<T>> ady = bosque.listaDeAdyacentes(v);
		ady.comenzar();
		while(!ady.fin()) {
			Arista<T> a = ady.proximo();
			Vertice<T> vDest = a.verticeDestino();
			int posDest = vDest.getPosicion();
			if(!marca[posDest] && a.peso() < 5) {
				marca[posDest] = true;
				caminoAct.agregarFinal(vDest.dato());
				if(vDest.dato().equals("Nombre de destino")) {
					result.agregarFinal(caminoAct.clonar()); //se clona para no perder el camino actual cuando se borre luego
				}
				else {
					dfs(vDest,caminoAct, marca, result);
				}
				marca[posDest] = false;
				caminoAct.eliminarEn(caminoAct.tamanio()); //borra ultimo cuando vuelve de la recursion
			}
		}
	}
	
	public ListaGenerica<ListaGenerica<T>> buscarCaminos() {
		//inicializo caminoAct, marca, result
		ListaGenerica<T> caminoAct = new ListaEnlazadaGenerica<T>();
		ListaGenerica<ListaGenerica<T>> result = new ListaEnlazadaGenerica<ListaGenerica<T>>();
		boolean[]marca = new boolean[bosque.listaDeVertices().tamanio()+1];
		Vertice<T> v = buscarCasaCaperucita(); 
		caminoAct.agregarFinal(v.dato());
		dfs(v, caminoAct, marca, result);
		return result;
	}
	
	private Vertice<T> buscarCasaCaperucita() {
		//busqueda secuencial
		ListaGenerica<Vertice<T>> vertices = bosque.listaDeVertices();
		vertices.comenzar();
		while(!vertices.fin()) {
			Vertice<T> v = vertices.proximo();
			if(v.dato().equals("Nombre de Vertice Partida")) {
				return v;
			}
		}
		return null; //si no lo encuentra devuelve null
		//podria realizar chequeos "if != null"
	}

	
}
