/**
 * 
 */
package tp06.ejercicio3;

import tp02.ejercicio2.ListaEnlazadaGenerica;
import tp02.ejercicio2.ListaGenerica;

/**
 * Implementacion del grafo con matriz
 * 
 * @author juan
 *
 */
public class GrafoImplMatrizAdy<T>
    implements Grafo<T> {
    private int maxVertices;
    ListaGenerica<Vertice<T>> vertices;
    int[][] matrizAdy;

    public GrafoImplMatrizAdy(int maxVert) {
    	//constructor de grafo de matriz
    	//crea lista de vertices y matriz tama�o pasado +1, pos[0][n] queda(n) vacia, y asigna valor 0
        // Para ser compatible con la lista la matriz comienza en 1
        maxVertices = maxVert;
        vertices = new ListaEnlazadaGenerica<Vertice<T>>();
        matrizAdy = new int[maxVertices + 1][maxVertices + 1];
        for (int i = 1; i <= maxVertices; i++) {
            for (int j = 0; j < maxVertices; j++) {
                matrizAdy[i][j] = 0;
            }
        }
    }

    @Override
    public void agregarVertice(Vertice<T> v) {
    	//si no hay un vertice == v, lo agrega al final de la lista de vertices
        if (!vertices.incluye(v)) {
            vertices.agregarFinal(v);
            ((VerticeImplMatrizAdy<T>) v).setPosicion(vertices.tamanio());
        }
    }

    @Override
    public void eliminarVertice(Vertice<T> v) {
    	//toma la pos del vertice y realiza corrimiento (sobreescritura) para eliminar la fila del vertice
        int index = ((VerticeImplMatrizAdy<T>) v).getPosicion();
        // Elimino la fila
        for (int fila = index; fila <= vertices.tamanio(); fila++) {
            matrizAdy[fila] = matrizAdy[fila + 1];
        }
        // Elimino la columna
        for (int fila = 0; fila <= vertices.tamanio(); fila++) {
            for (int col = index; col < vertices.tamanio(); col++) {
                matrizAdy[fila][col] = matrizAdy[fila][col + 1];
            }
        }
        vertices.eliminar(v);
    }

    @Override
    public void conectar(Vertice<T> origen, Vertice<T> destino) {
    	//conecta vertice origen con destino (1 = hay conexion)
        conectar(origen, destino, 1);

    }

    @Override
    public void conectar(Vertice<T> origen, Vertice<T> destino, int peso) {
    	//conecta vertice origen con destino y asigna peso
        matrizAdy[((VerticeImplMatrizAdy<T>) origen).getPosicion()][((VerticeImplMatrizAdy<T>) destino)
            .getPosicion()] = peso;
    }

    @Override
    public void desConectar(Vertice<T> origen, Vertice<T> destino) {
    	//pone en 0 (= false) el valor de la posicion correspondiente a la union vertices origen-destino
        matrizAdy[((VerticeImplMatrizAdy<T>) origen).getPosicion()][((VerticeImplMatrizAdy<T>) destino).getPosicion()] = 0;
    }

    @Override
    public boolean esAdyacente(Vertice<T> origen, Vertice<T> destino) {
    	//comprueba si la posicion correspondiente a origen y destino es 0 (devuelve false) o no (true)
        return matrizAdy[((VerticeImplMatrizAdy<T>) origen).getPosicion()][((VerticeImplMatrizAdy<T>) destino)
            .getPosicion()] > 0;
    }

    @Override
    public boolean esVacio() {
    	//determina si la lista de vertices es vacia
        return vertices.esVacia();
    }

    @Override
    public ListaGenerica<Vertice<T>> listaDeVertices() {
    	//devuelve lista de vertices
        return vertices;
    }

    @Override
    public int peso(Vertice<T> origen, Vertice<T> destino) {
    	//devuelve el paso correspondiente a la conexion origen-destino
        return matrizAdy[((VerticeImplMatrizAdy<T>) origen).getPosicion()][((VerticeImplMatrizAdy<T>) destino)
            .getPosicion()];
    }

    @Override
    public ListaGenerica<Arista<T>> listaDeAdyacentes(Vertice<T> v) {
    	//recorre la columna correspondiente al vertice y si una posicion es mayor a 0 (que quiere decir que existe conexion) la agrega a la lisa de adyacentes
        ListaGenerica<Arista<T>> ady = new ListaEnlazadaGenerica<Arista<T>>();
        int verticePos = ((VerticeImplMatrizAdy<T>) v).getPosicion();
        Arista<T> arista;
        for (int i = 1; i <= vertices.tamanio(); i++) {
            if (matrizAdy[verticePos][i] > 0) {
                arista = new AristaImpl<T>(vertices.elemento(i), matrizAdy[verticePos][i]);
                ady.agregarFinal(arista);
            }
        }
        return ady;
    }

    @Override
    public Vertice<T> vertice(int posicion) {
    	//devuelve el contenido de un vertice
        return vertices.elemento(posicion);
    }
}
